import { useState, useReducer, useEffect } from "react";

// ════ TEXTES PAR DÉFAUT ════
const DEFAULT_TEXTS = {
  hero_eyebrow:        "Compagnie Hydraulique du Sénégal",
  hero_title_line1:    "Équipements sanitaires",
  hero_title_line2:    "& hydrauliques",
  hero_title_accent:   "professionnels",
  hero_subtitle:       "Pompes Shimge · Articles sanitaires · Raccordement hydraulique",
  hero_tagline:        "Qualité · Modernité · Accessibilité",
  hero_cta_primary:    "Voir le catalogue →",
  hero_cta_secondary:  "⚙️ Pompes Shimge",
  hero_stat1_value:    "500+",
  hero_stat1_label:    "Produits",
  hero_stat2_value:    "100%",
  hero_stat2_label:    "Shimge certifié",
  hero_stat3_value:    "48h",
  hero_stat3_label:    "Livraison Dakar",
  hero_stat4_value:    "5 ans",
  hero_stat4_label:    "Garantie pompes",
  catalog_title:       "Nos gammes de produits",
  catalog_subtitle:    "Des équipements hydrauliques et sanitaires pour tous vos projets au Sénégal",
  featured_title:      "Sélection vedette",
  featured_subtitle:   "Nos best-sellers et nouveautés",
  footer_description:  "Spécialiste pompes Shimge, sanitaires et raccordement hydraulique.",
  cat_pompe_desc:      "Gamme complète : centrifuges, submersibles, circulateurs, surpresseurs",
  cat_sanitaire_desc:  "Lavabos, WC, baignoires, douches, robinetterie de qualité",
  cat_raccord_desc:    "Raccords laiton, vannes, clapets, flexibles, tubes PER",
};

// ════ PERSISTENCE localStorage ════
function loadState(){
  try {
    const saved = localStorage.getItem("chs_state");
    if(saved) {
      const parsed = JSON.parse(saved);
      return { ...parsed, texts: { ...DEFAULT_TEXTS, ...(parsed.texts||{}) } };
    }
  } catch(e){}
  return null;
}
function saveState(state){
  try {
    const toSave = { products: state.products, cats: state.cats, users: state.users, config: state.config, texts: state.texts, orders: state.orders };
    localStorage.setItem("chs_state", JSON.stringify(toSave));
  } catch(e){}
}

// ════ DATA — Catalogue Shimge complet + Sanitaires + Raccords ════
const SHIMGE = [
  { id:101, category:"pompe", sub:"Centrifuges de surface", name:"Shimge SG-1500B", brand:"Shimge", price:85000, unit:"pièce", stock:8, img:"⚙️", featured:true, active:true, desc:"Pompe centrifuge 1500W, débit 70L/min, HMT 52m, 220V. Corps fonte, roue inox.", specs:{Puissance:"1500W",Débit:"70 L/min",HMT:"52 m",Tension:"220V",Poids:"8.5 kg"} },
  { id:102, category:"pompe", sub:"Centrifuges de surface", name:"Shimge SG-750B",  brand:"Shimge", price:52000, unit:"pièce", stock:12,img:"⚙️", featured:false,active:true, desc:"Pompe centrifuge 750W, débit 45L/min, HMT 35m, 220V. Silencieuse, compacte.", specs:{Puissance:"750W",Débit:"45 L/min",HMT:"35 m"} },
  { id:103, category:"pompe", sub:"Centrifuges de surface", name:"Shimge SG-1100B", brand:"Shimge", price:67000, unit:"pièce", stock:6, img:"⚙️", featured:false,active:true, desc:"Pompe centrifuge 1100W, débit 58L/min, HMT 45m. Moteur à protection thermique.", specs:{Puissance:"1100W",Débit:"58 L/min",HMT:"45 m"} },
  { id:104, category:"pompe", sub:"Auto-amorçantes Jet",   name:"Shimge SG-JET 100L",brand:"Shimge",price:78000,unit:"pièce",stock:7, img:"⚙️", featured:true, active:true, desc:"Surpresseur auto-amorçant 750W + cuve 24L. Débit 40L/min, aspiration 8m, pressostat intégré.", specs:{Puissance:"750W",Débit:"40 L/min",Aspiration:"8 m",Cuve:"24 L",Pression:"2.8 bar"} },
  { id:105, category:"pompe", sub:"Auto-amorçantes Jet",   name:"Shimge SG-JET 200L",brand:"Shimge",price:95000,unit:"pièce",stock:4, img:"⚙️", featured:false,active:true, desc:"Surpresseur 1100W + cuve 50L. Pression constante 3.5 bar. Pressostat numérique.", specs:{Puissance:"1100W",Débit:"55 L/min",Cuve:"50 L",Pression:"3.5 bar"} },
  { id:106, category:"pompe", sub:"Auto-amorçantes Jet",   name:"Shimge SG-JET 50", brand:"Shimge", price:58000, unit:"pièce", stock:10,img:"⚙️", featured:false,active:true, desc:"Pompe jet compacte 550W + cuve 8L. Aspiration 8m. Démarrage auto par pressostat.", specs:{Puissance:"550W",Débit:"32 L/min",Cuve:"8 L"} },
  { id:107, category:"pompe", sub:"Submersibles immergées", name:"Shimge 4SP2/11",   brand:"Shimge", price:145000,unit:"pièce",stock:3, img:"⚙️", featured:true, active:true, desc:"Pompe submersible 4\" 1.5kW, débit 32L/min, HMT 85m. Corps inox 304. Pour forages.", specs:{Puissance:"1.5 kW",Débit:"32 L/min",HMT:"85 m",Diamètre:"4\"",Matériau:"Inox 304"} },
  { id:108, category:"pompe", sub:"Submersibles immergées", name:"Shimge 4SP3/8",    brand:"Shimge", price:162000,unit:"pièce",stock:2, img:"⚙️", featured:false,active:true, desc:"Pompe immergée 4\" 2.2kW, débit 48L/min, HMT 60m. Triphasé 380V.", specs:{Puissance:"2.2 kW",Débit:"48 L/min",HMT:"60 m",Tension:"380V tri"} },
  { id:109, category:"pompe", sub:"Submersibles immergées", name:"Shimge SP2-5/8 2\"",brand:"Shimge",price:68000,unit:"pièce",stock:8, img:"⚙️", featured:false,active:true, desc:"Pompe submersible 2\" 0.5kW pour puits. HMT 40m, câble 10m inclus.", specs:{Puissance:"0.5 kW",HMT:"40 m",Câble:"10 m inclus"} },
  { id:110, category:"pompe", sub:"Submersibles immergées", name:"Shimge Vide-cave VC-750",brand:"Shimge",price:48000,unit:"pièce",stock:11,img:"⚙️",featured:false,active:true, desc:"Vide-cave 750W. Passe à 3mm du sol. Débit 250L/min. Flotteur inclus.", specs:{Puissance:"750W",Débit:"250 L/min","H. min":"3 mm"} },
  { id:111, category:"pompe", sub:"Circulateurs chauffage", name:"Shimge SG-25/4G", brand:"Shimge", price:38000, unit:"pièce", stock:14,img:"⚙️", featured:false,active:true, desc:"Circulateur ECS 65W, Rp1\", DN25, H max 4m, débit 2.5m³/h, 3 vitesses.", specs:{Puissance:"65W",Raccord:"Rp 1\"",Débit:"2.5 m³/h","H max":"4 m"} },
  { id:112, category:"pompe", sub:"Circulateurs chauffage", name:"Shimge SG-32/6G", brand:"Shimge", price:52000, unit:"pièce", stock:9, img:"⚙️", featured:false,active:true, desc:"Circulateur chauffage 90W, DN32, Rp1\"1/4, H max 6m, débit 3.5m³/h.", specs:{Puissance:"90W",Raccord:"Rp 1\"1/4",Débit:"3.5 m³/h"} },
  { id:113, category:"pompe", sub:"Surpresseurs hydrophones",name:"Shimge SG-WZB 800",brand:"Shimge",price:98000,unit:"pièce",stock:6,img:"⚙️",featured:true,active:true, desc:"Surpresseur 800W, pressostat numérique 1-5 bar, cuve 24L. Protection manque d'eau.", specs:{Puissance:"800W",Pression:"1–5 bar",Cuve:"24 L"} },
  { id:114, category:"pompe", sub:"Surpresseurs hydrophones",name:"Shimge SG-WZB 1500",brand:"Shimge",price:135000,unit:"pièce",stock:4,img:"⚙️",featured:false,active:true, desc:"Surpresseur industriel 1500W, cuve 60L, débit 80L/min, 380V tri.", specs:{Puissance:"1500W",Pression:"2–6 bar",Cuve:"60 L",Débit:"80 L/min"} },
  { id:115, category:"pompe", sub:"Accessoires pompes",      name:"Pressostat numérique LCD",brand:"Shimge",price:18500,unit:"pièce",stock:20,img:"⚙️",featured:false,active:true, desc:"Pressostat électronique LCD 1-8 bar. Protection manque d'eau. Raccord 1\".", specs:{Plage:"1–8 bar",Affichage:"LCD",Raccord:"1\" BSP"} },
  { id:116, category:"pompe", sub:"Accessoires pompes",      name:"Réservoir membrane 50L", brand:"Shimge",price:42000,unit:"pièce",stock:8, img:"⚙️",featured:false,active:true, desc:"Vase d'expansion à membrane 50L pour surpresseur. Pmax 10 bar. Raccord 3/4\".", specs:{Volume:"50 L",Pmax:"10 bar",Raccord:"3/4\""} },
];

const SANITAIRE = [
  { id:201, category:"sanitaire", sub:"Lavabos & Vasques", name:"Lavabo céramique blanc 60cm",  brand:"Sanitec",  price:28500, unit:"pièce", stock:15,img:"🚿",featured:true, active:true, desc:"Lavabo à poser 60×46cm, céramique vitrifiée blanc brillant. Trou robinetterie Ø35mm.", specs:{Dimensions:"60×46 cm",Matériau:"Céramique"} },
  { id:202, category:"sanitaire", sub:"Lavabos & Vasques", name:"Vasque encastrée ronde Ø42", brand:"Sanitec",  price:35000, unit:"pièce", stock:10,img:"🚿",featured:false,active:true, desc:"Vasque ronde à encastrer Ø42cm, céramique blanche. Design contemporain.", specs:{Diamètre:"Ø42 cm",Pose:"Encastrée"} },
  { id:203, category:"sanitaire", sub:"Lavabos & Vasques", name:"Lavabo semi-colonne 55cm",    brand:"Sanitec",  price:42000, unit:"pièce", stock:8, img:"🚿",featured:false,active:true, desc:"Lavabo 55×45cm avec demi-colonne assortie. Masque les raccords.", specs:{Dimensions:"55×45 cm",Inclus:"Demi-colonne"} },
  { id:204, category:"sanitaire", sub:"WC & Réservoirs",   name:"WC à poser complet",           brand:"Sanitec",  price:65000, unit:"pièce", stock:9, img:"🚽",featured:true, active:true, desc:"Pack WC cuvette + réservoir attenant. Chasse 6/3L double débit. Abattant frein de chute.", specs:{Chasse:"6/3 L",Abattant:"Frein de chute"} },
  { id:205, category:"sanitaire", sub:"WC & Réservoirs",   name:"WC suspendu Rimless",          brand:"CeraStyle",price:98000, unit:"pièce", stock:5, img:"🚽",featured:true, active:true, desc:"WC suspendu sans bride (Rimless). Nettoyage facilité. Bâti-support non inclus.", specs:{Type:"Suspendu",Tech:"Rimless"} },
  { id:206, category:"sanitaire", sub:"Douches & Baignoires",name:"Receveur douche 80×80 extra-plat",brand:"BainPro",price:55000,unit:"pièce",stock:7,img:"🛁",featured:false,active:true, desc:"Receveur acrylique 80×80cm, hauteur 3cm. Bonde Ø90mm incluse.", specs:{Dimensions:"80×80 cm","H.":"3 cm",Matériau:"Acrylique"} },
  { id:207, category:"sanitaire", sub:"Douches & Baignoires",name:"Baignoire acrylique 170×70",  brand:"BainPro",price:145000,unit:"pièce",stock:3,img:"🛁",featured:true,active:true, desc:"Baignoire 170×70cm acrylique blanc. Pieds chromés réglables inclus. Évacuation Ø52mm.", specs:{Dimensions:"170×70 cm",Pieds:"Inclus"} },
  { id:208, category:"sanitaire", sub:"Robinetterie",       name:"Mitigeur lavabo chromé",       brand:"HydroChrome",price:18500,unit:"pièce",stock:25,img:"🔧",featured:false,active:true, desc:"Mitigeur monocommande lavabo laiton chromé. Cartouche céramique Ø35mm.", specs:{Corps:"Laiton chromé",Cartouche:"Céramique Ø35"} },
  { id:209, category:"sanitaire", sub:"Robinetterie",       name:"Mitigeur thermostatique douche",brand:"HydroChrome",price:48000,unit:"pièce",stock:8,img:"🔧",featured:false,active:true, desc:"Mitigeur thermostatique encastré 2 sorties. Sécurité anti-brûlure 38°C.", specs:{Type:"Thermostatique",Sorties:"2","Sécu.":"38°C"} },
  { id:210, category:"sanitaire", sub:"Robinetterie",       name:"Colonne de douche inox complète",brand:"HydroChrome",price:75000,unit:"pièce",stock:6,img:"🚿",featured:false,active:true, desc:"Colonne douche inox réglable 90-120cm. Pomme Ø25cm, douchette, mitigeur inclus.", specs:{Hauteur:"90–120 cm",Pomme:"Ø25 cm",Matériau:"Inox 304"} },
];

const RACCORD = [
  { id:301, category:"raccord", sub:"Raccords laiton",        name:"Té égal laiton 3/4\"",       brand:"HydroFit",price:1800, unit:"pièce",stock:150,img:"🔩",featured:false,active:true, desc:"Té égal laiton forgé F/F/F 3/4\". Pmax 25 bar.", specs:{Dimension:"3/4\"",Pmax:"25 bar"} },
  { id:302, category:"raccord", sub:"Raccords laiton",        name:"Manchon réduit 1\"×3/4\"",   brand:"HydroFit",price:1500, unit:"pièce",stock:120,img:"🔩",featured:false,active:true, desc:"Réduction M/F laiton 1\"×3/4\". Corps forgé, étanchéité PTFE.", specs:{Réduction:"1\"×3/4\""} },
  { id:303, category:"raccord", sub:"Raccords laiton",        name:"Coude 90° laiton 1/2\"",     brand:"HydroFit",price:1200, unit:"pièce",stock:200,img:"🔩",featured:false,active:true, desc:"Coude 90° laiton M/F 1/2\". Pmax 25 bar.", specs:{Angle:"90°",Dimension:"1/2\""} },
  { id:304, category:"raccord", sub:"Vannes & Clapets",       name:"Vanne boisseau sphérique 1\"",brand:"HydroFit",price:8500, unit:"pièce",stock:40, img:"🔩",featured:true, active:true, desc:"Robinet à bille laiton chromé F/F 1\". Poignée papillon. Pn 25 bar.", specs:{Dimension:"1\"",Type:"Bille",Pmax:"25 bar"} },
  { id:305, category:"raccord", sub:"Vannes & Clapets",       name:"Clapet anti-retour 3/4\"",   brand:"HydroFit",price:4800, unit:"pièce",stock:55, img:"🔩",featured:false,active:true, desc:"Clapet non-retour laiton 3/4\". Ouverture 0.1 bar. Tout sens.", specs:{Dimension:"3/4\"",Ouverture:"0.1 bar"} },
  { id:306, category:"raccord", sub:"Vannes & Clapets",       name:"Filtre Y tamis inox 1\"",    brand:"HydroFit",price:9500, unit:"pièce",stock:30, img:"🔩",featured:false,active:true, desc:"Filtre tamis inox 1\", maille 500μm. Bouchon démontable. Pmax 16 bar.", specs:{Dimension:"1\"",Maille:"500 μm"} },
  { id:307, category:"raccord", sub:"Tuyauterie flexible",    name:"Flexible inox 1/2\" L.40cm", brand:"HydroFit",price:3200, unit:"pièce",stock:80, img:"🔩",featured:false,active:true, desc:"Flexible raccordement tressé inox 1/2\"×40cm. Pmax 16 bar.", specs:{Longueur:"40 cm",Pmax:"16 bar"} },
  { id:308, category:"raccord", sub:"Tuyauterie flexible",    name:"Tube PER rouge Ø16 (ml)",    brand:"HydroFit",price:850,  unit:"mètre",stock:500,img:"🔩",featured:false,active:true, desc:"Tube PER-b gainé rouge Ø16×2mm. Eau chaude 95°C max. Au mètre.", specs:{Diamètre:"Ø16×2 mm","T° max":"95°C"} },
  { id:309, category:"raccord", sub:"Tuyauterie flexible",    name:"Tube PER bleu Ø16 (ml)",     brand:"HydroFit",price:850,  unit:"mètre",stock:500,img:"🔩",featured:false,active:true, desc:"Tube PER-b gainé bleu Ø16×2mm. Eau froide. Au mètre.", specs:{Diamètre:"Ø16×2 mm",Usage:"Eau froide"} },
  { id:310, category:"raccord", sub:"Raccords compression PE",name:"Coude 90° compression PE Ø32",brand:"HydroFit",price:2200,unit:"pièce",stock:70, img:"🔩",featured:false,active:true, desc:"Coude compression 90° PE Ø32mm. Pmax 16 bar. Eau potable.", specs:{Diamètre:"Ø32 mm",Pmax:"16 bar"} },
];

const ALL_PRODS = [...SHIMGE, ...SANITAIRE, ...RACCORD];

const INIT_CATS = [
  { id:"all", label:"Tous les produits", icon:"🏪" },
  { id:"pompe",    label:"Pompes Shimge",            icon:"⚙️", subs:["Centrifuges de surface","Auto-amorçantes Jet","Submersibles immergées","Circulateurs chauffage","Surpresseurs hydrophones","Accessoires pompes"] },
  { id:"sanitaire",label:"Articles sanitaires",      icon:"🚿", subs:["Lavabos & Vasques","WC & Réservoirs","Douches & Baignoires","Robinetterie","Accessoires sanitaires"] },
  { id:"raccord",  label:"Raccordement hydraulique", icon:"🔩", subs:["Raccords laiton","Vannes & Clapets","Tuyauterie flexible","Raccords compression PE","Raccords PVC évacuation","Raccords PVC pression"] },
];

const ST = {
  pending:  {label:"En attente",   c:"#D97706",bg:"#FEF3C7",dot:"#F59E0B"},
  confirmed:{label:"Confirmée",    c:"#1D4ED8",bg:"#DBEAFE",dot:"#3B82F6"},
  shipped:  {label:"En livraison", c:"#7C3AED",bg:"#EDE9FE",dot:"#8B5CF6"},
  delivered:{label:"Livrée",       c:"#065F46",bg:"#D1FAE5",dot:"#10B981"},
  cancelled:{label:"Annulée",      c:"#991B1B",bg:"#FEE2E2",dot:"#EF4444"},
};

const REGIONS_SN = ["Dakar","Thiès","Saint-Louis","Ziguinchor","Diourbel","Louga","Fatick","Kaolack","Kolda","Tambacounda","Kaffrine","Kédougou","Matam","Sédhiou"];
const CHS_WA = "221775294814";

// ════ REDUCER ════
function mkId(orders){ return `CHS-${new Date().getFullYear()}-${String(orders.length+1).padStart(4,"0")}`; }
function reducer(s, a){
  switch(a.type){
    case"NAV":          return{...s,page:a.p,adminSection:a.sec||"dashboard"};
    case"ASEC":         return{...s,adminSection:a.sec};
    case"SET_CAT":      return{...s,shopCat:a.cat,shopSub:a.sub||null,page:"shop"};
    case"SEARCH":       return{...s,search:a.v};
    case"VIEW_PROD":    return{...s,viewProd:a.p,page:"product"};
    case"ADD_CART":{
      const ex=s.cart.find(i=>i.id===a.p.id);
      if(ex) return{...s,cart:s.cart.map(i=>i.id===a.p.id?{...i,qty:i.qty+1}:i)};
      return{...s,cart:[...s.cart,{...a.p,qty:1}]};
    }
    case"RM_CART":      return{...s,cart:s.cart.filter(i=>i.id!==a.id)};
    case"UPD_QTY":      return{...s,cart:s.cart.map(i=>i.id===a.id?{...i,qty:Math.max(1,a.qty)}:i)};
    case"CLEAR_CART":   return{...s,cart:[]};
    case"PLACE_ORDER":{
      const o={...a.data,id:mkId(s.orders),status:"pending",date:new Date().toLocaleDateString("fr-SN"),ts:Date.now()};
      return{...s,orders:[o,...s.orders],cart:[],lastOrder:o};
    }
    case"UPD_ORDER":    return{...s,orders:s.orders.map(o=>o.id===a.id?{...o,status:a.status,updTs:Date.now()}:o)};
    case"LOGIN":        return{...s,user:a.user,page:"admin",adminSection:"dashboard"};
    case"LOGOUT":       return{...s,user:null,page:"home"};
    case"UPD_PROD":     return{...s,products:s.products.map(p=>p.id===a.p.id?a.p:p)};
    case"ADD_PROD":     return{...s,products:[...s.products,{...a.p,id:Date.now(),active:true}]};
    case"DEL_PROD":     return{...s,products:s.products.filter(p=>p.id!==a.id)};
    case"TOG_PROD":     return{...s,products:s.products.map(p=>p.id===a.id?{...p,active:!p.active}:p)};
    case"ADD_USER":     return{...s,users:[...s.users,{...a.u,id:Date.now(),active:true}]};
    case"UPD_USER":     return{...s,users:s.users.map(u=>u.id===a.u.id?a.u:u)};
    case"DEL_USER":     return{...s,users:s.users.filter(u=>u.id!==a.id)};
    case"SET_CFG":      return{...s,config:{...s.config,...a.cfg}};
    case"UPD_TEXT":     return{...s,texts:{...s.texts,[a.key]:a.value}};
    case"RESET_TEXTS":  return{...s,texts:{...DEFAULT_TEXTS}};
    case"ADD_CAT":      return{...s,cats:[...s.cats,{id:"cat_"+Date.now(),label:a.label,icon:a.icon||"📦",subs:[]}]};
    case"UPD_CAT":      return{...s,cats:s.cats.map(c=>c.id===a.id?{...c,...a.data}:c)};
    case"DEL_CAT":      return{...s,cats:s.cats.filter(c=>c.id!==a.id)};
    case"ADD_SUB":      return{...s,cats:s.cats.map(c=>c.id===a.catId?{...c,subs:[...c.subs,a.sub]}:c)};
    case"DEL_SUB":      return{...s,cats:s.cats.map(c=>c.id===a.catId?{...c,subs:c.subs.filter(s2=>s2!==a.sub)}:c)};
    default: return s;
  }
}
const INIT={
  page:"home",adminSection:"dashboard",shopCat:"all",shopSub:null,search:"",viewProd:null,
  cart:[],orders:[],lastOrder:null,user:null,
  products:ALL_PRODS,
  cats:INIT_CATS,
  users:[{id:1,username:"admin",password:"chs2025",role:"admin",name:"Administrateur CHS",email:"admin@chs-sn.com",active:true}],
  config:{siteName:"CHS",company:"Compagnie Hydraulique du Sénégal",tagline:"Qualité · Modernité · Accessibilité",phone:"+221 77 529 48 14",whatsapp:CHS_WA,email:"contact@chs-sn.com",address:"Dakar, Sénégal",currency:"FCFA",showBanner:true,bannerText:"🚚 Livraison sur Dakar et régions — Contactez-nous pour un devis gratuit"},
  texts:{...DEFAULT_TEXTS},
};

// ════ CSS ════
const CSS=`
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Inter:wght@300;400;500;600;700;800&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
:root{--bk:#080808;--wh:#fff;--cy:#1BAEDB;--cy2:#0d8ab3;--gn:#1A5C32;--rd:#B91C1C;--gr:#F5F5F5;--mid:#6B7280;--bd:#E5E7EB;--nav:#0F2744;--ser:'Playfair Display',serif;--san:'Inter',sans-serif;--r:8px;--sh:0 1px 6px rgba(0,0,0,.08);--sh2:0 6px 28px rgba(0,0,0,.14);}
body{font-family:var(--san);background:#F8F8F8;color:var(--bk);}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:10px 20px;border:none;border-radius:var(--r);font-weight:600;font-size:.875rem;cursor:pointer;transition:all .15s;text-decoration:none;font-family:var(--san);white-space:nowrap;}
.bk{background:var(--bk);color:#fff;}.bk:hover{background:#1a1a1a;}
.cy{background:var(--cy);color:#fff;}.cy:hover{background:var(--cy2);}
.gn{background:var(--gn);color:#fff;}.gn:hover{background:#134a27;}
.rd{background:var(--rd);color:#fff;}.rd:hover{background:#991b1b;}
.gh{background:transparent;border:1.5px solid var(--bd);color:#374151;}.gh:hover{background:var(--gr);}
.ol{background:transparent;border:2px solid var(--bk);color:var(--bk);}.ol:hover{background:var(--bk);color:#fff;}
.sm{padding:6px 13px;font-size:.78rem;}
.lg{padding:13px 26px;font-size:1rem;}
.xl{padding:15px 30px;font-size:1.05rem;}
.btn:disabled{opacity:.4;cursor:not-allowed;}
.tag{display:inline-flex;align-items:center;padding:2px 9px;border-radius:20px;font-size:.68rem;font-weight:700;letter-spacing:.4px;text-transform:uppercase;}
.tp{background:#FEF3C7;color:#92400E;}
.ts{background:#DBEAFE;color:#1E40AF;}
.tr{background:#D1FAE5;color:#065F46;}
input,select,textarea{width:100%;padding:10px 13px;border:1.5px solid var(--bd);border-radius:var(--r);font-family:var(--san);font-size:.9rem;transition:border .2s;background:#fff;color:var(--bk);}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--cy);}
input::placeholder{color:#9CA3AF;}
.mb{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:300;display:flex;align-items:center;justify-content:center;padding:16px;backdrop-filter:blur(2px);}
.md{background:#fff;border-radius:14px;padding:28px;width:100%;max-width:580px;max-height:92vh;overflow-y:auto;}
.bdg{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;border-radius:9px;background:var(--rd);color:#fff;font-size:.62rem;font-weight:800;padding:0 4px;}
.ok{padding:11px 15px;background:#D1FAE5;color:#065F46;border:1px solid #6EE7B7;border-radius:var(--r);font-size:.875rem;margin-bottom:12px;}
.er{padding:11px 15px;background:#FEE2E2;color:#7F1D1D;border:1px solid #FCA5A5;border-radius:var(--r);font-size:.875rem;margin-bottom:12px;}
.fg{display:flex;flex-direction:column;gap:5px;margin-bottom:13px;}
.fg label{font-size:.8rem;font-weight:700;color:#374151;}
.rq{color:var(--rd);}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:13px;}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:13px;}
.card{background:#fff;border:1.5px solid var(--bd);border-radius:10px;}
hr.dv{border:none;border-top:1px solid var(--bd);margin:18px 0;}
@media(max-width:860px){.g2,.g3{grid-template-columns:1fr;}}
`;

// ════ LOGO ════
function Logo({h=36,dark=false}){
  const c=dark?"#fff":"#080808";
  return(
    <svg width={h*2.8} height={h} viewBox="0 0 140 50" style={{display:"block",flexShrink:0}}>
      <path d="M15 31 Q7 23 7 16 Q7 5 16 5 Q25 5 25 16 Q25 23 15 31Z" fill="#1BAEDB"/>
      <ellipse cx="15" cy="31" rx="5" ry="3" fill="#1BAEDB" opacity=".6"/>
      <text x="30" y="33" fontFamily="Georgia,serif" fontWeight="900" fontSize="30" fill={c} letterSpacing="-1">CHS</text>
      <rect x="30" y="35.5" width="106" height="2.5" fill="#1BAEDB"/>
      <rect x="30" y="38" width="33" height="7" fill="#1A5C32"/>
      <rect x="63" y="38" width="33" height="7" fill={dark?"rgba(255,255,255,.75)":"#DADADA"}/>
      <rect x="96" y="38" width="40" height="7" fill="#B91C1C"/>
    </svg>
  );
}

// ════ WA HELPERS ════
function waLink(num,msg){return `https://wa.me/${num}?text=${encodeURIComponent(msg)}`;}
function buildConfirmMsg(o){
  const items=o.items.map(i=>`  • ${i.name} × ${i.qty} = ${(i.price*i.qty).toLocaleString()} ${o.currency}`).join("\n");
  return `✅ *Confirmation de commande CHS*\n\nBonjour ${o.prenom} ${o.nom},\n\nVotre commande *${o.id}* a bien été reçue par la *Compagnie Hydraulique du Sénégal*.\n\n📋 *Récapitulatif :*\n${items}\n\n💰 *Total : ${o.total.toLocaleString()} ${o.currency}*\n\n📍 *Livraison :* ${o.adresse}${o.quartier?", "+o.quartier:""} — ${o.commune?o.commune+", ":""}${o.region}\n📞 *Votre contact :* ${o.telephone}\n\nNotre équipe vous recontactera très prochainement pour confirmer la livraison.\n\nMerci de votre confiance ! 🙏\n\n*Équipe CHS — Dakar, Sénégal*`;
}


// ════ BANNER + HEADER ════
function Banner({state,dispatch}){
  if(!state.config.showBanner)return null;
  return(<div style={{background:"#0F2744",color:"#fff",textAlign:"center",padding:"8px 16px",fontSize:".8rem",fontWeight:500,display:"flex",alignItems:"center",justifyContent:"center",gap:8}}><span>{state.config.bannerText}</span><button onClick={()=>dispatch({type:"SET_CFG",cfg:{showBanner:false}})} style={{background:"none",border:"none",color:"rgba(255,255,255,.5)",cursor:"pointer",fontSize:".9rem"}}>✕</button></div>);
}
function Header({state,dispatch}){
  const qty=state.cart.reduce((s,i)=>s+i.qty,0);
  return(
    <header style={{background:"#fff",borderBottom:"1px solid var(--bd)",position:"sticky",top:0,zIndex:100,boxShadow:"0 1px 6px rgba(0,0,0,.06)"}}>
      <div style={{maxWidth:1280,margin:"0 auto",padding:"0 20px",display:"flex",alignItems:"center",gap:18,height:64}}>
        <div style={{cursor:"pointer",flexShrink:0}} onClick={()=>dispatch({type:"NAV",p:"home"})}><Logo h={32}/></div>
        <nav style={{display:"flex",gap:2,flex:1,flexWrap:"wrap"}}>
          {[{l:"Accueil",p:"home"},{l:"Boutique",p:"shop"},{l:"Pompes Shimge",cat:"pompe"},{l:"Sanitaires",cat:"sanitaire"},{l:"Raccords",cat:"raccord"}].map(n=>(
            <button key={n.l} className="btn gh sm" style={{border:"none",fontWeight:500,fontSize:".82rem",color:"#374151",padding:"6px 10px"}}
              onClick={()=>n.cat?dispatch({type:"SET_CAT",cat:n.cat}):dispatch({type:"NAV",p:n.p})}>{n.l}</button>
          ))}
        </nav>
        <div style={{display:"flex",gap:8,alignItems:"center",flexShrink:0}}>
          <input value={state.search} onChange={e=>dispatch({type:"SEARCH",v:e.target.value})}
            onKeyDown={e=>e.key==="Enter"&&dispatch({type:"NAV",p:"shop"})}
            placeholder="Rechercher…" style={{width:180,fontSize:".82rem",padding:"7px 11px"}}/>
          <button className="btn bk sm" onClick={()=>dispatch({type:"NAV",p:"cart"})} style={{position:"relative",gap:6}}>
            🛒 {qty>0&&<span className="bdg">{qty}</span>}
          </button>
          {state.user
            ?<button className="btn gn sm" onClick={()=>dispatch({type:"NAV",p:"admin"})}>⚙ Admin</button>
            :<button className="btn gh sm" onClick={()=>dispatch({type:"NAV",p:"login"})}>Connexion</button>}
        </div>
      </div>
    </header>
  );
}

// ════ HERO ════
function Hero({dispatch,texts}){
  const t=texts||DEFAULT_TEXTS;
  return(
    <section style={{background:"#080808",color:"#fff",position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",top:0,left:0,right:0,height:4,display:"flex"}}>
        <div style={{flex:1,background:"#1A5C32"}}/><div style={{flex:1,background:"rgba(255,255,255,.12)"}}/><div style={{flex:1,background:"#B91C1C"}}/>
      </div>
      <div style={{position:"absolute",inset:0,backgroundImage:"radial-gradient(circle at 2px 2px,rgba(27,174,219,.1) 1px,transparent 0)",backgroundSize:"34px 34px"}}/>
      <div style={{maxWidth:1280,margin:"0 auto",padding:"86px 24px 78px",position:"relative"}}>
        <div style={{maxWidth:640}}>
          <div style={{marginBottom:18}}><Logo h={42} dark/></div>
          <div style={{fontSize:".72rem",fontWeight:700,letterSpacing:"2px",color:"var(--cy)",textTransform:"uppercase",marginBottom:12}}>{t.hero_eyebrow}</div>
          <h1 style={{fontFamily:"var(--ser)",fontSize:"clamp(2rem,5vw,3.5rem)",fontWeight:900,lineHeight:1.08,marginBottom:16,letterSpacing:"-.5px"}}>
            {t.hero_title_line1}<br/>{t.hero_title_line2}<br/><span style={{color:"var(--cy)"}}>{t.hero_title_accent}</span>
          </h1>
          <p style={{fontSize:"1rem",opacity:.72,lineHeight:1.75,marginBottom:8,maxWidth:480}}>{t.hero_subtitle}</p>
          <p style={{fontFamily:"var(--ser)",fontStyle:"italic",color:"rgba(255,255,255,.45)",fontSize:".95rem",marginBottom:34}}>{t.hero_tagline}</p>
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            <button className="btn cy xl" onClick={()=>dispatch({type:"NAV",p:"shop"})}>{t.hero_cta_primary}</button>
            <button className="btn xl" style={{border:"2px solid rgba(255,255,255,.28)",color:"#fff",background:"transparent"}} onClick={()=>dispatch({type:"SET_CAT",cat:"pompe"})}>{t.hero_cta_secondary}</button>
          </div>
        </div>
      </div>
      <div style={{background:"rgba(255,255,255,.04)",borderTop:"1px solid rgba(255,255,255,.07)"}}>
        <div style={{maxWidth:1280,margin:"0 auto",padding:"22px 24px",display:"grid",gridTemplateColumns:"repeat(4,1fr)"}}>
          {[[t.hero_stat1_value,t.hero_stat1_label],[t.hero_stat2_value,t.hero_stat2_label],[t.hero_stat3_value,t.hero_stat3_label],[t.hero_stat4_value,t.hero_stat4_label]].map(([n,l],i)=>(
            <div key={i} style={{textAlign:"center",padding:"10px 0",borderRight:i<3?"1px solid rgba(255,255,255,.07)":"none"}}>
              <div style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700,color:"var(--cy)"}}>{n}</div>
              <div style={{fontSize:".75rem",opacity:.5,marginTop:2}}>{l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ════ CATEGORY CARDS ════
function CatCards({dispatch,texts}){
  const t=texts||DEFAULT_TEXTS;
  const cats=[
    {cat:"pompe",icon:"⚙️",title:"Pompes Shimge",desc:t.cat_pompe_desc,count:SHIMGE.length,bg:"#FEF3C7",brd:"#FDE68A",tc:"#92400E"},
    {cat:"sanitaire",icon:"🚿",title:"Articles sanitaires",desc:t.cat_sanitaire_desc,count:SANITAIRE.length,bg:"#DBEAFE",brd:"#BFDBFE",tc:"#1E40AF"},
    {cat:"raccord",icon:"🔩",title:"Raccordement hydraulique",desc:t.cat_raccord_desc,count:RACCORD.length,bg:"#D1FAE5",brd:"#A7F3D0",tc:"#065F46"},
  ];
  return(
    <section style={{maxWidth:1280,margin:"0 auto",padding:"52px 24px 0"}}>
      <h2 style={{fontFamily:"var(--ser)",fontSize:"1.7rem",fontWeight:700,marginBottom:8,textAlign:"center"}}>{t.catalog_title}</h2>
      <p style={{textAlign:"center",color:"var(--mid)",marginBottom:28,fontSize:".88rem"}}>{t.catalog_subtitle}</p>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:18}}>
        {cats.map(c=>(
          <div key={c.cat} onClick={()=>dispatch({type:"SET_CAT",cat:c.cat})}
            style={{background:c.bg,border:`1.5px solid ${c.brd}`,borderRadius:12,padding:26,cursor:"pointer",transition:"all .18s"}}
            onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-4px)";e.currentTarget.style.boxShadow="var(--sh2)";}}
            onMouseLeave={e=>{e.currentTarget.style.transform="";e.currentTarget.style.boxShadow="";}}>
            <div style={{fontSize:"2.2rem",marginBottom:10}}>{c.icon}</div>
            <div style={{fontFamily:"var(--ser)",fontWeight:700,fontSize:"1.15rem",marginBottom:6}}>{c.title}</div>
            <div style={{fontSize:".83rem",color:"#374151",lineHeight:1.6,marginBottom:14}}>{c.desc}</div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span style={{fontSize:".75rem",fontWeight:600,opacity:.6}}>{c.count} références</span>
              <span style={{fontSize:".8rem",fontWeight:700,color:c.tc}}>Explorer →</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ════ PRODUCT CARD ════
function ProdCard({p,dispatch,currency}){
  const[added,setAdded]=useState(false);
  const doAdd=e=>{e.stopPropagation();dispatch({type:"ADD_CART",p});setAdded(true);setTimeout(()=>setAdded(false),1500);};
  if(!p.active)return null;
  const tagClass=p.category==="pompe"?"tp":p.category==="sanitaire"?"ts":"tr";
  return(
    <div onClick={()=>dispatch({type:"VIEW_PROD",p})}
      style={{background:"#fff",border:"1.5px solid var(--bd)",borderRadius:10,overflow:"hidden",cursor:"pointer",transition:"all .18s",display:"flex",flexDirection:"column"}}
      onMouseEnter={e=>{e.currentTarget.style.borderColor="var(--cy)";e.currentTarget.style.boxShadow="var(--sh2)";e.currentTarget.style.transform="translateY(-2px)";}}
      onMouseLeave={e=>{e.currentTarget.style.borderColor="var(--bd)";e.currentTarget.style.boxShadow="";e.currentTarget.style.transform="";}}>
      <div style={{background:"#F5F7FA",height:142,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"3rem",position:"relative"}}>
        {p.img}
        {p.featured&&<div style={{position:"absolute",top:8,left:8,background:"#080808",color:"#fff",fontSize:".6rem",fontWeight:800,padding:"2px 7px",borderRadius:4,letterSpacing:".5px"}}>VEDETTE</div>}
        {p.stock<=3&&p.stock>0&&<div style={{position:"absolute",top:8,right:8,background:"#FEF3C7",color:"#92400E",fontSize:".6rem",fontWeight:700,padding:"2px 6px",borderRadius:4}}>Stock limité</div>}
        {p.stock===0&&<div style={{position:"absolute",inset:0,background:"rgba(0,0,0,.32)",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontWeight:700,fontSize:".82rem"}}>Épuisé</div>}
      </div>
      <div style={{padding:"13px 13px 15px",flex:1,display:"flex",flexDirection:"column"}}>
        <div style={{marginBottom:6}}><span className={`tag ${tagClass}`}>{p.sub}</span></div>
        <h3 style={{fontWeight:700,fontSize:".86rem",lineHeight:1.4,flex:1,marginBottom:7}}>{p.name}</h3>
        {p.specs&&<div style={{display:"flex",flexWrap:"wrap",gap:"3px 7px",marginBottom:9}}>{Object.entries(p.specs).slice(0,3).map(([k,v])=><span key={k} style={{fontSize:".65rem",background:"#F4F4F4",color:"#374151",padding:"2px 6px",borderRadius:4}}>{v}</span>)}</div>}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:"auto"}}>
          <div>
            <span style={{fontFamily:"var(--ser)",fontSize:"1.1rem",fontWeight:700}}>{p.price.toLocaleString()}</span>
            <span style={{fontSize:".7rem",color:"var(--mid)",marginLeft:3}}>{currency}/{p.unit}</span>
          </div>
          <button className={`btn sm ${added?"gn":"cy"}`} disabled={p.stock===0} onClick={doAdd} style={{minWidth:76}}>
            {added?"✓ Ajouté":"+ Panier"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ════ FEATURED + SHOP ════
function Featured({state,dispatch}){
  const featured=state.products.filter(p=>p.featured&&p.active);
  const t=state.texts||DEFAULT_TEXTS;
  return(
    <section style={{maxWidth:1280,margin:"0 auto",padding:"50px 24px 0"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
        <div><h2 style={{fontFamily:"var(--ser)",fontSize:"1.6rem",fontWeight:700}}>{t.featured_title}</h2><p style={{color:"var(--mid)",fontSize:".83rem",marginTop:3}}>{t.featured_subtitle}</p></div>
        <button className="btn ol sm" onClick={()=>dispatch({type:"NAV",p:"shop"})}>Voir tout →</button>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(210px,1fr))",gap:14}}>
        {featured.map(p=><ProdCard key={p.id} p={p} dispatch={dispatch} currency={state.config.currency}/>)}
      </div>
    </section>
  );
}

function ShopPage({state,dispatch}){
  const[sort,setSort]=useState("default");
  const[pmax,setPmax]=useState(500000);
  const CATS=state.cats;
  const cat=CATS.find(c=>c.id===state.shopCat)||CATS[0];
  let prods=state.products.filter(p=>
    p.active&&
    (state.shopCat==="all"||p.category===state.shopCat)&&
    (!state.shopSub||p.sub===state.shopSub)&&
    (!state.search||p.name.toLowerCase().includes(state.search.toLowerCase())||(p.desc||"").toLowerCase().includes(state.search.toLowerCase()))&&
    p.price<=pmax
  );
  if(sort==="asc")prods=[...prods].sort((a,b)=>a.price-b.price);
  if(sort==="desc")prods=[...prods].sort((a,b)=>b.price-a.price);
  if(sort==="name")prods=[...prods].sort((a,b)=>a.name.localeCompare(b.name));
  return(
    <div style={{maxWidth:1280,margin:"0 auto",padding:"30px 24px",display:"flex",gap:22}}>
      <aside style={{width:224,flexShrink:0}}>
        <div className="card" style={{padding:16,marginBottom:14}}>
          <div style={{fontSize:".68rem",fontWeight:800,letterSpacing:"1px",textTransform:"uppercase",color:"var(--mid)",marginBottom:11}}>Catégories</div>
          {CATS.map(c=>(
            <div key={c.id}>
              <button onClick={()=>dispatch({type:"SET_CAT",cat:c.id})}
                style={{display:"flex",alignItems:"center",justifyContent:"space-between",width:"100%",textAlign:"left",padding:"8px 9px",border:"none",borderRadius:6,background:state.shopCat===c.id&&!state.shopSub?"#080808":"transparent",color:state.shopCat===c.id&&!state.shopSub?"#fff":"#374151",cursor:"pointer",fontWeight:state.shopCat===c.id?"700":"400",marginBottom:2,fontSize:".84rem"}}>
                <span>{c.icon} {c.label}</span>
              </button>
              {state.shopCat===c.id&&c.subs&&c.subs.map(sc=>(
                <button key={sc} onClick={()=>dispatch({type:"SET_CAT",cat:c.id,sub:sc})}
                  style={{display:"block",width:"100%",textAlign:"left",padding:"5px 9px 5px 22px",border:"none",borderRadius:6,background:state.shopSub===sc?"var(--cy)":"transparent",color:state.shopSub===sc?"#fff":"#6B7280",cursor:"pointer",fontSize:".76rem",fontWeight:state.shopSub===sc?"700":"400",marginBottom:1}}>
                  {sc}
                </button>
              ))}
            </div>
          ))}
        </div>
        <div className="card" style={{padding:16}}>
          <div style={{fontSize:".68rem",fontWeight:800,letterSpacing:"1px",textTransform:"uppercase",color:"var(--mid)",marginBottom:11}}>Budget max</div>
          <input type="range" min={500} max={500000} step={1000} value={pmax} onChange={e=>setPmax(+e.target.value)} style={{width:"100%",accentColor:"#080808",border:"none",padding:0,marginBottom:7}}/>
          <div style={{textAlign:"right",fontWeight:700,fontSize:".86rem"}}>{pmax.toLocaleString()} {state.config.currency}</div>
        </div>
      </aside>
      <main style={{flex:1,minWidth:0}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16,flexWrap:"wrap",gap:10}}>
          <div>
            <h2 style={{fontFamily:"var(--ser)",fontSize:"1.4rem",fontWeight:700}}>{state.shopSub||cat.label}</h2>
            <div style={{fontSize:".78rem",color:"var(--mid)",marginTop:2}}>{prods.length} article(s)</div>
          </div>
          <select value={sort} onChange={e=>setSort(e.target.value)} style={{width:"auto",padding:"6px 11px",fontSize:".82rem"}}>
            <option value="default">Trier</option><option value="asc">Prix ↑</option><option value="desc">Prix ↓</option><option value="name">A–Z</option>
          </select>
        </div>
        {prods.length===0
          ?<div style={{textAlign:"center",padding:"60px 0",color:"var(--mid)"}}>Aucun produit trouvé</div>
          :<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(205px,1fr))",gap:13}}>
            {prods.map(p=><ProdCard key={p.id} p={p} dispatch={dispatch} currency={state.config.currency}/>)}
          </div>}
      </main>
    </div>
  );
}

// ════ PRODUCT DETAIL ════
function ProdDetail({state,dispatch}){
  const p=state.viewProd;if(!p)return null;
  const rel=state.products.filter(r=>r.category===p.category&&r.id!==p.id&&r.active).slice(0,4);
  const tc=p.category==="pompe"?"tp":p.category==="sanitaire"?"ts":"tr";
  return(
    <div style={{maxWidth:1100,margin:"0 auto",padding:"30px 24px"}}>
      <button className="btn gh sm" style={{marginBottom:18}} onClick={()=>dispatch({type:"NAV",p:"shop"})}>← Retour</button>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:34,background:"#fff",border:"1.5px solid var(--bd)",borderRadius:12,padding:30}}>
        <div style={{background:"#F5F7FA",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"7rem",minHeight:250}}>{p.img}</div>
        <div>
          <span className={`tag ${tc}`}>{p.sub}</span>
          <h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700,margin:"12px 0 6px",lineHeight:1.2}}>{p.name}</h1>
          <div style={{fontSize:".83rem",color:"var(--mid)",marginBottom:14}}>Marque : <strong>{p.brand}</strong></div>
          <p style={{color:"#374151",lineHeight:1.75,marginBottom:16,fontSize:".9rem"}}>{p.desc}</p>
          {p.specs&&Object.keys(p.specs).length>0&&(
            <div style={{background:"#F5F7FA",borderRadius:8,padding:14,marginBottom:16}}>
              <div style={{fontWeight:700,fontSize:".72rem",textTransform:"uppercase",letterSpacing:".5px",marginBottom:9,color:"var(--mid)"}}>Caractéristiques</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"5px 12px"}}>
                {Object.entries(p.specs).map(([k,v])=>(
                  <div key={k} style={{fontSize:".8rem"}}><span style={{color:"var(--mid)"}}>{k} : </span><strong>{v}</strong></div>
                ))}
              </div>
            </div>
          )}
          <div style={{background:"#F5F7FA",borderRadius:8,padding:14,marginBottom:20}}>
            <div style={{fontFamily:"var(--ser)",fontSize:"1.9rem",fontWeight:700}}>{p.price.toLocaleString()} <span style={{fontSize:".9rem",fontFamily:"var(--san)",fontWeight:400,color:"var(--mid)"}}>{state.config.currency}/{p.unit}</span></div>
            <div style={{fontSize:".78rem",fontWeight:700,marginTop:3,color:p.stock>5?"#065F46":p.stock>0?"#92400E":"#991B1B"}}>{p.stock>0?`✓ En stock — ${p.stock} disponible(s)`:"✗ Rupture de stock"}</div>
          </div>
          <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
            <button className="btn bk lg" disabled={p.stock===0} onClick={()=>{dispatch({type:"ADD_CART",p});dispatch({type:"NAV",p:"cart"});}}>🛒 Commander</button>
            <button className="btn gh lg" disabled={p.stock===0} onClick={()=>dispatch({type:"ADD_CART",p})}>+ Ajouter au panier</button>
          </div>
        </div>
      </div>
      {rel.length>0&&(
        <div style={{marginTop:42}}>
          <h3 style={{fontFamily:"var(--ser)",fontSize:"1.3rem",fontWeight:700,marginBottom:16}}>Produits similaires</h3>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(205px,1fr))",gap:13}}>
            {rel.map(r=><ProdCard key={r.id} p={r} dispatch={dispatch} currency={state.config.currency}/>)}
          </div>
        </div>
      )}
    </div>
  );
}

// ════ ORDER MODAL ════
function OrderModal({cart,config,onClose,onSubmit}){
  const total=cart.reduce((s,i)=>s+i.price*i.qty,0);
  const[f,setF]=useState({nom:"",prenom:"",telephone:"",whatsapp:"",email:"",region:"",commune:"",adresse:"",quartier:"",notes:"",sameNum:true});
  const[err,setErr]=useState("");
  const set=(k,v)=>setF(prev=>({...prev,[k]:v}));
  const submit=()=>{
    if(!f.nom||!f.prenom||!f.telephone||!f.region||!f.adresse){setErr("Veuillez remplir tous les champs obligatoires (*).");return;}
    const wa=f.sameNum?f.telephone.replace(/\D/g,""):f.whatsapp.replace(/\D/g,"");
    onSubmit({...f,whatsapp:wa,items:cart.map(i=>({id:i.id,name:i.name,qty:i.qty,price:i.price,unit:i.unit})),total,currency:config.currency});
  };
  return(
    <div className="mb">
      <div className="md">
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"start",marginBottom:20}}>
          <div><Logo h={24}/><h2 style={{fontFamily:"var(--ser)",fontSize:"1.3rem",fontWeight:700,marginTop:10}}>Finaliser la commande</h2><p style={{fontSize:".78rem",color:"var(--mid)",marginTop:2}}>Renseignez vos informations de livraison</p></div>
          <button className="btn gh sm" onClick={onClose}>✕</button>
        </div>
        <div style={{background:"#F5F7FA",borderRadius:8,padding:13,marginBottom:16}}>
          <div style={{fontWeight:700,fontSize:".7rem",textTransform:"uppercase",letterSpacing:".5px",marginBottom:7,color:"var(--mid)"}}>Votre commande</div>
          {cart.map(i=>(
            <div key={i.id} style={{display:"flex",justifyContent:"space-between",fontSize:".82rem",padding:"3px 0",borderBottom:"1px solid var(--bd)"}}>
              <span>{i.name} × {i.qty} {i.unit}</span><strong>{(i.price*i.qty).toLocaleString()} {config.currency}</strong>
            </div>
          ))}
          <div style={{display:"flex",justifyContent:"space-between",marginTop:7,fontFamily:"var(--ser)",fontSize:"1.1rem",fontWeight:700}}>
            <span>Total</span><span>{total.toLocaleString()} {config.currency}</span>
          </div>
        </div>
        {err&&<div className="er">{err}</div>}
        <div style={{fontWeight:700,fontSize:".68rem",textTransform:"uppercase",letterSpacing:".8px",color:"var(--mid)",marginBottom:11}}>Informations personnelles</div>
        <div className="g2">
          <div className="fg"><label>Prénom <span className="rq">*</span></label><input value={f.prenom} onChange={e=>set("prenom",e.target.value)} placeholder="Votre prénom"/></div>
          <div className="fg"><label>Nom <span className="rq">*</span></label><input value={f.nom} onChange={e=>set("nom",e.target.value)} placeholder="Votre nom"/></div>
        </div>
        <div className="fg"><label>Téléphone <span className="rq">*</span></label><input value={f.telephone} onChange={e=>set("telephone",e.target.value)} placeholder="+221 77 000 00 00" type="tel"/></div>
        <div className="fg" style={{marginBottom:8}}>
          <label style={{display:"flex",alignItems:"center",gap:7,cursor:"pointer",fontSize:".85rem",fontWeight:500}}>
            <input type="checkbox" checked={f.sameNum} onChange={e=>set("sameNum",e.target.checked)} style={{width:"auto"}}/>
            Mon numéro WhatsApp est identique à mon téléphone
          </label>
        </div>
        {!f.sameNum&&<div className="fg"><label>Numéro WhatsApp <span className="rq">*</span></label><input value={f.whatsapp} onChange={e=>set("whatsapp",e.target.value)} placeholder="+221 77 000 00 00" type="tel"/></div>}
        <div className="fg"><label>Email (optionnel)</label><input value={f.email} onChange={e=>set("email",e.target.value)} placeholder="email@exemple.com" type="email"/></div>
        <hr className="dv"/>
        <div style={{fontWeight:700,fontSize:".68rem",textTransform:"uppercase",letterSpacing:".8px",color:"var(--mid)",marginBottom:11}}>Adresse de livraison</div>
        <div className="g2">
          <div className="fg">
            <label>Région <span className="rq">*</span></label>
            <select value={f.region} onChange={e=>set("region",e.target.value)}>
              <option value="">-- Sélectionner --</option>
              {REGIONS_SN.map(r=><option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div className="fg"><label>Commune / Ville</label><input value={f.commune} onChange={e=>set("commune",e.target.value)} placeholder="Ex: Parcelles Assainies"/></div>
        </div>
        <div className="fg"><label>Adresse complète <span className="rq">*</span></label><input value={f.adresse} onChange={e=>set("adresse",e.target.value)} placeholder="Numéro, rue, quartier précis"/></div>
        <div className="fg"><label>Point de repère</label><input value={f.quartier} onChange={e=>set("quartier",e.target.value)} placeholder="Ex: En face de la mosquée…"/></div>
        <div className="fg"><label>Instructions / Notes</label><textarea rows={2} value={f.notes} onChange={e=>set("notes",e.target.value)} placeholder="Disponibilité, instructions pour le livreur…"/></div>
        <button className="btn bk lg" style={{width:"100%",marginTop:8}} onClick={submit}>✓ Confirmer la commande</button>
        <p style={{fontSize:".7rem",color:"var(--mid)",textAlign:"center",marginTop:9,lineHeight:1.5}}>Vous recevrez une confirmation sur WhatsApp. Notre équipe vous contactera pour valider la livraison.</p>
      </div>
    </div>
  );
}

// ════ CART PAGE ════
function CartPage({state,dispatch}){
  const[showModal,setShowModal]=useState(false);
  const[done,setDone]=useState(false);
  const total=state.cart.reduce((s,i)=>s+i.price*i.qty,0);
  const handleOrder=data=>{dispatch({type:"PLACE_ORDER",data});setShowModal(false);setDone(true);};
  if(done&&state.lastOrder){
    const o=state.lastOrder;const msg=buildConfirmMsg(o);
    return(
      <div style={{maxWidth:540,margin:"60px auto",padding:"0 24px",textAlign:"center"}}>
        <div className="card" style={{padding:42}}>
          <div style={{width:70,height:70,borderRadius:"50%",background:"#D1FAE5",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"2rem",margin:"0 auto 16px"}}>✅</div>
          <Logo h={28}/>
          <h2 style={{fontFamily:"var(--ser)",fontSize:"1.7rem",fontWeight:700,margin:"14px 0 8px"}}>Commande envoyée !</h2>
          <div style={{background:"#F5F7FA",borderRadius:8,padding:"9px 14px",margin:"12px 0",fontSize:".88rem"}}>Référence : <strong>{o.id}</strong></div>
          <p style={{color:"var(--mid)",lineHeight:1.75,marginBottom:18,fontSize:".88rem"}}>Votre commande a été transmise à notre équipe CHS. Vous recevrez une confirmation WhatsApp au <strong>{o.telephone}</strong>.</p>
          <a href={waLink(CHS_WA,msg)} target="_blank" rel="noopener noreferrer" className="btn gn lg" style={{width:"100%",marginBottom:8}}>💬 Envoyer confirmation WhatsApp</a>
          <p style={{fontSize:".7rem",color:"var(--mid)",marginBottom:18}}>Cliquez pour envoyer le message de confirmation depuis le compte WhatsApp CHS (+221 77 529 48 14)</p>
          <button className="btn bk" onClick={()=>{setDone(false);dispatch({type:"NAV",p:"home"});}}>Retour à l'accueil</button>
        </div>
      </div>
    );
  }
  if(state.cart.length===0)return(
    <div style={{maxWidth:460,margin:"70px auto",padding:"0 24px",textAlign:"center"}}>
      <div style={{fontSize:"3.5rem",marginBottom:14}}>🛒</div>
      <h2 style={{fontFamily:"var(--ser)",fontSize:"1.7rem",fontWeight:700,marginBottom:10}}>Panier vide</h2>
      <p style={{color:"var(--mid)",marginBottom:22}}>Parcourez notre catalogue pour trouver vos articles.</p>
      <button className="btn bk" onClick={()=>dispatch({type:"NAV",p:"shop"})}>Voir le catalogue</button>
    </div>
  );
  return(
    <>
      {showModal&&<OrderModal cart={state.cart} config={state.config} onClose={()=>setShowModal(false)} onSubmit={handleOrder}/>}
      <div style={{maxWidth:960,margin:"0 auto",padding:"30px 24px"}}>
        <h1 style={{fontFamily:"var(--ser)",fontSize:"1.9rem",fontWeight:700,marginBottom:26}}>Mon panier</h1>
        <div style={{display:"grid",gridTemplateColumns:"1fr 290px",gap:20}}>
          <div>
            {state.cart.map(item=>(
              <div key={item.id} className="card" style={{padding:14,marginBottom:10,display:"flex",gap:13,alignItems:"center"}}>
                <div style={{fontSize:"1.9rem",width:46,textAlign:"center",flexShrink:0}}>{item.img}</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontWeight:700,fontSize:".86rem",marginBottom:2}}>{item.name}</div>
                  <div style={{fontSize:".76rem",color:"var(--mid)"}}>{item.price.toLocaleString()} {state.config.currency} / {item.unit}</div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:7,flexShrink:0}}>
                  <button className="btn gh sm" onClick={()=>dispatch({type:"UPD_QTY",id:item.id,qty:item.qty-1})}>−</button>
                  <span style={{fontWeight:700,minWidth:20,textAlign:"center",fontSize:".9rem"}}>{item.qty}</span>
                  <button className="btn gh sm" onClick={()=>dispatch({type:"UPD_QTY",id:item.id,qty:item.qty+1})}>+</button>
                </div>
                <div style={{fontWeight:700,minWidth:84,textAlign:"right",fontSize:".88rem",flexShrink:0}}>{(item.price*item.qty).toLocaleString()} {state.config.currency}</div>
                <button className="btn rd sm" onClick={()=>dispatch({type:"RM_CART",id:item.id})}>✕</button>
              </div>
            ))}
          </div>
          <div className="card" style={{padding:20,height:"fit-content",position:"sticky",top:74}}>
            <div style={{fontWeight:800,fontSize:".72rem",textTransform:"uppercase",letterSpacing:".5px",marginBottom:12}}>Total commande</div>
            {state.cart.map(i=>(
              <div key={i.id} style={{display:"flex",justifyContent:"space-between",fontSize:".78rem",marginBottom:5,color:"var(--mid)"}}>
                <span style={{maxWidth:150,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{i.name} ×{i.qty}</span>
                <span>{(i.price*i.qty).toLocaleString()}</span>
              </div>
            ))}
            <hr className="dv" style={{margin:"11px 0"}}/>
            <div style={{display:"flex",justifyContent:"space-between",fontFamily:"var(--ser)",fontSize:"1.3rem",fontWeight:700,marginBottom:16}}>
              <span>Total</span><span>{total.toLocaleString()} {state.config.currency}</span>
            </div>
            <button className="btn bk lg" style={{width:"100%"}} onClick={()=>setShowModal(true)}>Passer la commande →</button>
          </div>
        </div>
      </div>
    </>
  );
}

// ════ LOGIN ════
function LoginPage({state,dispatch}){
  const[u,setU]=useState("");const[p,setP]=useState("");const[err,setErr]=useState("");
  const go=()=>{
    const user=state.users.find(x=>x.username===u&&x.password===p&&x.active);
    if(user)dispatch({type:"LOGIN",user});else setErr("Identifiants incorrects ou compte désactivé.");
  };
  return(
    <div style={{maxWidth:390,margin:"70px auto",padding:"0 24px"}}>
      <div className="card" style={{padding:34}}>
        <div style={{textAlign:"center",marginBottom:22}}><Logo h={32}/></div>
        <h2 style={{fontFamily:"var(--ser)",fontSize:"1.45rem",fontWeight:700,textAlign:"center",marginBottom:4}}>Portail CHS</h2>
        <p style={{color:"var(--mid)",textAlign:"center",fontSize:".8rem",marginBottom:20}}>Accès réservé à l'équipe CHS</p>
        {err&&<div className="er">{err}</div>}
        <div className="fg"><label>Identifiant</label><input value={u} onChange={e=>setU(e.target.value)} placeholder="Votre identifiant"/></div>
        <div className="fg"><label>Mot de passe</label><input type="password" value={p} onChange={e=>setP(e.target.value)} onKeyDown={e=>e.key==="Enter"&&go()} placeholder="••••••••"/></div>
        <button className="btn bk lg" style={{width:"100%",marginTop:7}} onClick={go}>Se connecter</button>
        <p style={{textAlign:"center",fontSize:".7rem",color:"var(--mid)",marginTop:13}}>Démo : admin / chs2025</p>
      </div>
    </div>
  );
}

// ════ ADMIN LAYOUT ════
function AdminLayout({state,dispatch,children}){
  const isAdmin=state.user?.role==="admin";
  const pending=state.orders.filter(o=>o.status==="pending").length;
  const nav=[
    {id:"dashboard",icon:"📊",label:"Tableau de bord",roles:["admin","vendeur"]},
    {id:"orders",   icon:"📋",label:"Commandes",       roles:["admin","vendeur"],badge:pending},
    {id:"products", icon:"📦",label:"Produits",        roles:["admin"]},
    {id:"categories",icon:"🏷️",label:"Catégories",      roles:["admin"]},
    {id:"texts",    icon:"✏️", label:"Textes du site",  roles:["admin"]},
    {id:"users",    icon:"👥",label:"Collaborateurs",  roles:["admin"]},
    {id:"site",     icon:"⚙️",label:"Paramètres",      roles:["admin"]},
    {id:"publish",  icon:"🌐",label:"Publication",      roles:["admin"]},
  ].filter(n=>n.roles.includes(state.user?.role));
  return(
    <div style={{display:"flex",minHeight:"calc(100vh - 64px)"}}>
      <aside style={{width:232,background:"#080808",color:"#fff",padding:"16px 0",flexShrink:0,display:"flex",flexDirection:"column"}}>
        <div style={{padding:"0 16px 16px",borderBottom:"1px solid rgba(255,255,255,.08)",marginBottom:8}}>
          <Logo h={26} dark/>
          <div style={{marginTop:13,display:"flex",alignItems:"center",gap:8}}>
            <div style={{width:30,height:30,borderRadius:"50%",background:"var(--cy)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:".78rem",fontWeight:800,color:"#fff",flexShrink:0}}>{state.user?.name?.charAt(0).toUpperCase()}</div>
            <div style={{overflow:"hidden"}}>
              <div style={{fontSize:".78rem",fontWeight:700,color:"#fff",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{state.user?.name}</div>
              <div style={{fontSize:".65rem",color:"rgba(255,255,255,.45)",textTransform:"capitalize"}}>{state.user?.role}</div>
            </div>
          </div>
        </div>
        <div style={{flex:1}}>
          {nav.map(n=>(
            <button key={n.id} onClick={()=>dispatch({type:"ASEC",sec:n.id})}
              style={{display:"flex",alignItems:"center",justifyContent:"space-between",width:"100%",padding:"10px 16px",border:"none",background:state.adminSection===n.id?"rgba(255,255,255,.1)":"transparent",color:state.adminSection===n.id?"#fff":"rgba(255,255,255,.55)",cursor:"pointer",fontSize:".83rem",borderLeft:state.adminSection===n.id?"3px solid var(--cy)":"3px solid transparent",fontWeight:state.adminSection===n.id?"700":"400",transition:"all .13s"}}>
              <span style={{display:"flex",alignItems:"center",gap:8}}>{n.icon} {n.label}</span>
              {n.badge>0&&<span className="bdg">{n.badge}</span>}
            </button>
          ))}
        </div>
        <div style={{borderTop:"1px solid rgba(255,255,255,.08)",padding:"10px 0"}}>
          <button onClick={()=>dispatch({type:"NAV",p:"home"})} style={{display:"flex",alignItems:"center",gap:8,width:"100%",padding:"8px 16px",border:"none",background:"transparent",color:"rgba(255,255,255,.4)",cursor:"pointer",fontSize:".8rem"}}>↗ Voir le site</button>
          <button onClick={()=>dispatch({type:"LOGOUT"})} style={{display:"flex",alignItems:"center",gap:8,width:"100%",padding:"8px 16px",border:"none",background:"transparent",color:"#F87171",cursor:"pointer",fontSize:".8rem"}}>🚪 Déconnexion</button>
        </div>
      </aside>
      <main style={{flex:1,padding:26,overflowY:"auto",background:"#F8F8F8"}}>{children}</main>
    </div>
  );
}

// ════ ADMIN DASHBOARD ════
function ADash({state,dispatch}){
  const pending=state.orders.filter(o=>o.status==="pending").length;
  const confirmed=state.orders.filter(o=>o.status==="confirmed").length;
  const delivered=state.orders.filter(o=>o.status==="delivered").length;
  const revenue=state.orders.filter(o=>o.status!=="cancelled").reduce((s,o)=>s+o.total,0);
  return(
    <div>
      <h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700,marginBottom:5}}>Tableau de bord</h1>
      <p style={{color:"var(--mid)",fontSize:".85rem",marginBottom:24}}>Bienvenue, {state.user?.name}</p>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:13,marginBottom:26}}>
        {[
          {l:"En attente",v:pending,i:"⏳",c:"#D97706",action:()=>dispatch({type:"ASEC",sec:"orders"})},
          {l:"Confirmées",v:confirmed,i:"✅",c:"#1D4ED8"},
          {l:"Livrées",v:delivered,i:"📦",c:"#065F46"},
          {l:"CA total",v:revenue.toLocaleString()+" "+state.config.currency,i:"💰",c:"#7C3AED"},
        ].map(s=>(
          <div key={s.l} className="card" style={{padding:16,borderTop:`3px solid ${s.c}`,cursor:s.action?"pointer":"default"}} onClick={s.action}>
            <div style={{fontSize:"1.6rem",marginBottom:7}}>{s.i}</div>
            <div style={{fontFamily:"var(--ser)",fontSize:"1.7rem",fontWeight:700}}>{s.v}</div>
            <div style={{fontSize:".76rem",color:"var(--mid)",marginTop:2}}>{s.l}</div>
          </div>
        ))}
      </div>
      {pending>0&&<div style={{background:"#FEF3C7",border:"1px solid #FDE68A",borderRadius:10,padding:16,marginBottom:18}}><div style={{fontWeight:700,color:"#92400E",marginBottom:5}}>⏳ {pending} commande(s) en attente</div><button className="btn sm" style={{background:"#D97706",color:"#fff"}} onClick={()=>dispatch({type:"ASEC",sec:"orders"})}>Traiter →</button></div>}
      <div className="card" style={{padding:18}}>
        <div style={{fontWeight:700,marginBottom:12,fontSize:".82rem",textTransform:"uppercase",letterSpacing:".5px"}}>Alertes stock</div>
        {state.products.filter(p=>p.stock<=3&&p.active).length===0
          ?<div style={{color:"var(--mid)",fontSize:".86rem"}}>✓ Tous les stocks sont normaux</div>
          :state.products.filter(p=>p.stock<=3&&p.active).map(p=>(
            <div key={p.id} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid var(--bd)",fontSize:".86rem"}}>
              <span>{p.img} {p.name}</span><span style={{color:"#B91C1C",fontWeight:700}}>{p.stock} restant(s)</span>
            </div>
          ))}
      </div>
    </div>
  );
}

// ════ ADMIN ORDERS ════
function AOrders({state,dispatch}){
  const[filter,setFilter]=useState("all");
  const[expanded,setExpanded]=useState(null);
  const[search,setSearch]=useState("");
  const orders=state.orders.filter(o=>{
    const mf=filter==="all"||o.status===filter;
    const ms=!search||o.id.toLowerCase().includes(search.toLowerCase())||(o.nom+" "+o.prenom).toLowerCase().includes(search.toLowerCase())||o.telephone.includes(search);
    return mf&&ms;
  });
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,flexWrap:"wrap",gap:11}}>
        <h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700}}>Commandes</h1>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Rechercher par nom, réf, tél…" style={{width:270,fontSize:".83rem"}}/>
      </div>
      <div style={{display:"flex",gap:6,marginBottom:16,flexWrap:"wrap"}}>
        {["all",...Object.keys(ST)].map(s=>{
          const cnt=s==="all"?state.orders.length:state.orders.filter(o=>o.status===s).length;
          return(<button key={s} className={`btn sm ${filter===s?"bk":"gh"}`} onClick={()=>setFilter(s)}>{s==="all"?"Toutes":ST[s]?.label} <span style={{opacity:.55,marginLeft:2}}>({cnt})</span></button>);
        })}
      </div>
      {orders.length===0
        ?<div className="card" style={{padding:44,textAlign:"center",color:"var(--mid)"}}>Aucune commande trouvée</div>
        :orders.map(o=>{
          const sc=ST[o.status];const msg=buildConfirmMsg(o);
          return(
            <div key={o.id} className="card" style={{padding:17,marginBottom:9}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"start",flexWrap:"wrap",gap:11}}>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:6,flexWrap:"wrap"}}>
                    <span style={{fontWeight:800,fontSize:".93rem",fontFamily:"var(--ser)"}}>{o.id}</span>
                    <span style={{background:sc.bg,color:sc.c,padding:"2px 9px",borderRadius:12,fontSize:".68rem",fontWeight:700,display:"inline-flex",alignItems:"center",gap:3}}>
                      <span style={{width:5,height:5,borderRadius:"50%",background:sc.dot,display:"inline-block"}}></span>{sc.label}
                    </span>
                    <span style={{fontSize:".73rem",color:"var(--mid)"}}>📅 {o.date}</span>
                  </div>
                  <div style={{fontWeight:700,fontSize:".96rem",marginBottom:3}}>{o.prenom} {o.nom}</div>
                  <div style={{fontSize:".8rem",color:"var(--mid)",display:"flex",flexDirection:"column",gap:2}}>
                    <span>📞 {o.telephone}{o.email&&` · ✉ ${o.email}`}</span>
                    <span>📍 {o.adresse}{o.quartier?`, ${o.quartier}`:""} — {o.commune?`${o.commune}, `:""}{o.region}</span>
                    {o.notes&&<span style={{fontStyle:"italic"}}>💬 {o.notes}</span>}
                  </div>
                </div>
                <div style={{textAlign:"right",flexShrink:0}}>
                  <div style={{fontFamily:"var(--ser)",fontSize:"1.35rem",fontWeight:700,marginBottom:8}}>{o.total.toLocaleString()} {state.config.currency}</div>
                  <div style={{display:"flex",gap:5,justifyContent:"flex-end",flexWrap:"wrap"}}>
                    <button className="btn gh sm" onClick={()=>setExpanded(expanded===o.id?null:o.id)}>{expanded===o.id?"Masquer ▴":"Détails ▾"}</button>
                    {o.status==="pending"&&<><button className="btn sm" style={{background:"#1D4ED8",color:"#fff"}} onClick={()=>dispatch({type:"UPD_ORDER",id:o.id,status:"confirmed"})}>✓ Confirmer</button><button className="btn rd sm" onClick={()=>dispatch({type:"UPD_ORDER",id:o.id,status:"cancelled"})}>✕ Annuler</button></>}
                    {o.status==="confirmed"&&<button className="btn sm" style={{background:"#7C3AED",color:"#fff"}} onClick={()=>dispatch({type:"UPD_ORDER",id:o.id,status:"shipped"})}>🚚 En livraison</button>}
                    {o.status==="shipped"&&<button className="btn gn sm" onClick={()=>dispatch({type:"UPD_ORDER",id:o.id,status:"delivered"})}>📦 Livrée</button>}
                    <a href={waLink(o.whatsapp||o.telephone,msg)} target="_blank" rel="noopener noreferrer" className="btn sm" style={{background:"#25D366",color:"#fff"}}>WhatsApp</a>
                  </div>
                </div>
              </div>
              {expanded===o.id&&(
                <div style={{marginTop:14,borderTop:"1px solid var(--bd)",paddingTop:13}}>
                  <div style={{fontWeight:700,fontSize:".68rem",textTransform:"uppercase",letterSpacing:".5px",marginBottom:9,color:"var(--mid)"}}>Articles commandés</div>
                  <table style={{width:"100%",borderCollapse:"collapse",fontSize:".83rem"}}>
                    <thead><tr style={{background:"#F5F7FA"}}>{["Article","Qté","Prix unit.","Sous-total"].map(h=><th key={h} style={{padding:"7px 11px",textAlign:"left",fontWeight:700,fontSize:".75rem"}}>{h}</th>)}</tr></thead>
                    <tbody>
                      {o.items.map((item,i)=>(
                        <tr key={i} style={{borderBottom:"1px solid #F0F0F0"}}>
                          <td style={{padding:"7px 11px"}}>{item.name}</td>
                          <td style={{padding:"7px 11px"}}>{item.qty} {item.unit}</td>
                          <td style={{padding:"7px 11px"}}>{item.price.toLocaleString()} {state.config.currency}</td>
                          <td style={{padding:"7px 11px",fontWeight:700}}>{(item.price*item.qty).toLocaleString()} {state.config.currency}</td>
                        </tr>
                      ))}
                      <tr style={{borderTop:"2px solid var(--bd)"}}>
                        <td colSpan={3} style={{padding:"8px 11px",fontWeight:800,textAlign:"right"}}>TOTAL</td>
                        <td style={{padding:"8px 11px",fontFamily:"var(--ser)",fontSize:"1rem",fontWeight:700}}>{o.total.toLocaleString()} {state.config.currency}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          );
        })
      }
    </div>
  );
}

// ════ ADMIN PRODUCTS ════
function AProducts({state,dispatch}){
  const[editing,setEditing]=useState(null);const[adding,setAdding]=useState(false);
  const[form,setForm]=useState({});const[saved,setSaved]=useState(false);
  const[fcat,setFcat]=useState("all");const[fact,setFact]=useState("all");const[search,setSearch]=useState("");
  const openEdit=p=>{setForm({...p});setEditing(p.id);setAdding(false);};
  const openAdd=()=>{setForm({category:"pompe",sub:"",unit:"pièce",stock:10,featured:false,img:"⚙️",brand:"",price:0,active:true,desc:"",specs:{}});setAdding(true);setEditing(null);};
  const save=()=>{if(adding)dispatch({type:"ADD_PROD",p:form});else dispatch({type:"UPD_PROD",p:form});setEditing(null);setAdding(false);setSaved(true);setTimeout(()=>setSaved(false),2500);};
  const CATS=state.cats;
  const subCats=cat=>CATS.find(c=>c.id===cat)?.subs||[];
  const filtered=state.products.filter(p=>(fcat==="all"||p.category===fcat)&&(fact==="all"||(fact==="active"?p.active:!p.active))&&(!search||p.name.toLowerCase().includes(search.toLowerCase())));
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18,flexWrap:"wrap",gap:11}}>
        <h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700}}>Catalogue produits</h1>
        <button className="btn bk" onClick={openAdd}>+ Nouveau produit</button>
      </div>
      {saved&&<div className="ok">✓ Sauvegardé avec succès</div>}
      <div style={{display:"flex",gap:7,marginBottom:13,flexWrap:"wrap",alignItems:"center"}}>
        {CATS.map(c=><button key={c.id} className={`btn sm ${fcat===c.id?"bk":"gh"}`} onClick={()=>setFcat(c.id)}>{c.icon} {c.label}</button>)}
        <span style={{width:1,height:22,background:"var(--bd)",margin:"0 3px"}}/>
        <button className={`btn sm ${fact==="all"?"bk":"gh"}`} onClick={()=>setFact("all")}>Tous</button>
        <button className={`btn sm ${fact==="active"?"gn":"gh"}`} onClick={()=>setFact("active")}>Actifs</button>
        <button className={`btn sm ${fact==="inactive"?"rd":"gh"}`} onClick={()=>setFact("inactive")}>Désactivés</button>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Rechercher…" style={{width:170,fontSize:".78rem",padding:"5px 10px",marginLeft:"auto"}}/>
      </div>
      <div className="card" style={{overflow:"hidden"}}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr style={{background:"#F5F7FA",fontSize:".76rem"}}>{["Produit","Sous-catégorie","Prix","Stock","Statut","Actions"].map(h=><th key={h} style={{padding:"9px 13px",textAlign:"left",fontWeight:700}}>{h}</th>)}</tr></thead>
          <tbody>
            {filtered.map(p=>(
              <tr key={p.id} style={{borderBottom:"1px solid #F0F0F0",opacity:p.active?1:.5}}>
                <td style={{padding:"10px 13px"}}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span style={{fontSize:"1.2rem"}}>{p.img}</span>
                    <div><div style={{fontWeight:700,fontSize:".83rem"}}>{p.name}</div><div style={{fontSize:".7rem",color:"var(--mid)"}}>{p.brand}</div></div>
                  </div>
                </td>
                <td style={{padding:"10px 13px",fontSize:".76rem",color:"var(--mid)"}}>{p.sub}</td>
                <td style={{padding:"10px 13px",fontWeight:700,fontSize:".83rem"}}>{p.price.toLocaleString()} {state.config.currency}</td>
                <td style={{padding:"10px 13px",color:p.stock<=3?"#B91C1C":p.stock<=10?"#D97706":"#065F46",fontWeight:700}}>{p.stock}</td>
                <td style={{padding:"10px 13px"}}><span style={{background:p.active?"#D1FAE5":"#FEE2E2",color:p.active?"#065F46":"#991B1B",padding:"2px 8px",borderRadius:20,fontSize:".68rem",fontWeight:700}}>{p.active?"Actif":"Inactif"}</span></td>
                <td style={{padding:"10px 13px"}}>
                  <div style={{display:"flex",gap:4}}>
                    <button className="btn gh sm" onClick={()=>openEdit(p)}>✏</button>
                    <button className={`btn sm ${p.active?"gh":"gn"}`} onClick={()=>dispatch({type:"TOG_PROD",id:p.id})} title={p.active?"Désactiver":"Activer"}>{p.active?"⏸":"▶"}</button>
                    <button className="btn rd sm" onClick={()=>{if(confirm("Supprimer ce produit ?"))dispatch({type:"DEL_PROD",id:p.id});}}>🗑</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {(editing!==null||adding)&&(
        <div className="mb" onClick={e=>e.target===e.currentTarget&&setEditing(null)}>
          <div className="md">
            <h3 style={{fontFamily:"var(--ser)",fontSize:"1.25rem",fontWeight:700,marginBottom:16}}>{adding?"Nouveau produit":"Modifier le produit"}</h3>
            <div className="g2">
              <div className="fg"><label>Nom du produit</label><input value={form.name||""} onChange={e=>setForm({...form,name:e.target.value})}/></div>
              <div className="fg"><label>Marque</label><input value={form.brand||""} onChange={e=>setForm({...form,brand:e.target.value})}/></div>
            </div>
            <div className="g2">
              <div className="fg"><label>Catégorie</label><select value={form.category||"pompe"} onChange={e=>setForm({...form,category:e.target.value,sub:""})}>{CATS.filter(c=>c.id!=="all").map(c=><option key={c.id} value={c.id}>{c.label}</option>)}</select></div>
              <div className="fg"><label>Sous-catégorie</label><select value={form.sub||""} onChange={e=>setForm({...form,sub:e.target.value})}><option value="">-- Choisir --</option>{subCats(form.category||"pompe").map(sc=><option key={sc} value={sc}>{sc}</option>)}</select></div>
            </div>
            <div className="g3">
              <div className="fg"><label>Prix ({state.config.currency})</label><input type="number" value={form.price||0} onChange={e=>setForm({...form,price:+e.target.value})}/></div>
              <div className="fg"><label>Unité</label><input value={form.unit||""} onChange={e=>setForm({...form,unit:e.target.value})}/></div>
              <div className="fg"><label>Stock</label><input type="number" value={form.stock||0} onChange={e=>setForm({...form,stock:+e.target.value})}/></div>
            </div>
            <div className="g2">
              <div className="fg"><label>Icône (emoji)</label><input value={form.img||""} onChange={e=>setForm({...form,img:e.target.value})}/></div>
              <div className="fg" style={{justifyContent:"flex-end",paddingTop:20}}>
                <label style={{display:"flex",alignItems:"center",gap:7,cursor:"pointer",fontSize:".85rem"}}><input type="checkbox" checked={form.featured||false} onChange={e=>setForm({...form,featured:e.target.checked})} style={{width:"auto"}}/>Produit vedette</label>
              </div>
            </div>
            <div className="fg"><label>Description</label><textarea rows={3} value={form.desc||""} onChange={e=>setForm({...form,desc:e.target.value})}/></div>
            <div style={{display:"flex",gap:9,justifyContent:"flex-end",marginTop:5}}>
              <button className="btn gh" onClick={()=>{setEditing(null);setAdding(false);}}>Annuler</button>
              <button className="btn bk" onClick={save}>Sauvegarder</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ════ ADMIN USERS ════
function AUsers({state,dispatch}){
  const[adding,setAdding]=useState(false);const[editing,setEditing]=useState(null);const[form,setForm]=useState({});const[saved,setSaved]=useState(false);
  const openAdd=()=>{setForm({username:"",password:"",name:"",email:"",role:"vendeur",active:true});setAdding(true);setEditing(null);};
  const openEdit=u=>{setForm({...u});setEditing(u.id);setAdding(false);};
  const save=()=>{if(!form.username||!form.password||!form.name)return;if(adding)dispatch({type:"ADD_USER",u:form});else dispatch({type:"UPD_USER",u:form});setAdding(false);setEditing(null);setSaved(true);setTimeout(()=>setSaved(false),2500);};
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div><h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700}}>Collaborateurs</h1><p style={{color:"var(--mid)",fontSize:".83rem",marginTop:3}}>Gérez les accès au portail d'administration CHS</p></div>
        <button className="btn bk" onClick={openAdd}>+ Ajouter</button>
      </div>
      {saved&&<div className="ok">✓ Sauvegardé</div>}
      <div style={{background:"#FEF3C7",border:"1px solid #FDE68A",borderRadius:9,padding:14,marginBottom:20,fontSize:".83rem",color:"#78350F",lineHeight:1.7}}>
        <strong>🔐 Rôles :</strong> <strong>Admin</strong> — accès complet (commandes, produits, collaborateurs, paramètres). <strong>Vendeur</strong> — accès commandes uniquement (voir, confirmer, livrer, contacter via WhatsApp). Aucun accès aux produits, collaborateurs ou paramètres.
      </div>
      <div style={{display:"grid",gap:10}}>
        {state.users.map(u=>(
          <div key={u.id} className="card" style={{padding:16,display:"flex",alignItems:"center",gap:14,opacity:u.active?1:.6}}>
            <div style={{width:42,height:42,borderRadius:"50%",background:u.role==="admin"?"#080808":"var(--cy)",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontWeight:800,fontSize:"1rem",flexShrink:0}}>{u.name.charAt(0).toUpperCase()}</div>
            <div style={{flex:1}}>
              <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:2}}>
                <span style={{fontWeight:700}}>{u.name}</span>
                <span style={{background:u.role==="admin"?"#080808":"#DBEAFE",color:u.role==="admin"?"#fff":"#1E40AF",padding:"1px 7px",borderRadius:12,fontSize:".65rem",fontWeight:700,textTransform:"uppercase"}}>{u.role}</span>
                {!u.active&&<span style={{background:"#FEE2E2",color:"#991B1B",padding:"1px 7px",borderRadius:12,fontSize:".65rem",fontWeight:700}}>INACTIF</span>}
              </div>
              <div style={{fontSize:".79rem",color:"var(--mid)"}}> @{u.username}{u.email&&` · ${u.email}`}</div>
            </div>
            <div style={{display:"flex",gap:6}}>
              {u.id!==1&&<>
                <button className="btn gh sm" onClick={()=>openEdit(u)}>✏ Modifier</button>
                <button className={`btn sm ${u.active?"gh":"gn"}`} onClick={()=>dispatch({type:"UPD_USER",u:{...u,active:!u.active}})}>{u.active?"Désactiver":"Activer"}</button>
                <button className="btn rd sm" onClick={()=>{if(confirm("Supprimer ce collaborateur ?"))dispatch({type:"DEL_USER",id:u.id});}}>🗑</button>
              </>}
              {u.id===1&&<>
                <button className="btn gh sm" onClick={()=>openEdit(u)}>✏ Modifier mes identifiants</button>
                <span style={{fontSize:".75rem",color:"var(--mid)",fontStyle:"italic"}}>Compte principal</span>
              </>}
            </div>
          </div>
        ))}
      </div>
      {(adding||editing!==null)&&(
        <div className="mb" onClick={e=>e.target===e.currentTarget&&setEditing(null)}>
          <div className="md">
            <h3 style={{fontFamily:"var(--ser)",fontSize:"1.25rem",fontWeight:700,marginBottom:16}}>{adding?"Nouveau collaborateur":"Modifier"}</h3>
            <div className="fg"><label>Nom complet</label><input value={form.name||""} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Prénom Nom"/></div>
            <div className="g2">
              <div className="fg"><label>Identifiant</label><input value={form.username||""} onChange={e=>setForm({...form,username:e.target.value})} placeholder="ex: vendeur1"/></div>
              <div className="fg"><label>Mot de passe</label><input type="password" value={form.password||""} onChange={e=>setForm({...form,password:e.target.value})} placeholder="••••••••"/></div>
            </div>
            <div className="g2">
              <div className="fg"><label>Email</label><input value={form.email||""} onChange={e=>setForm({...form,email:e.target.value})} placeholder="email@exemple.com"/></div>
              <div className="fg"><label>Rôle</label><select value={form.role||"vendeur"} onChange={e=>setForm({...form,role:e.target.value})}><option value="vendeur">Vendeur</option><option value="admin">Admin</option></select></div>
            </div>
            <div style={{display:"flex",gap:9,justifyContent:"flex-end"}}>
              <button className="btn gh" onClick={()=>{setAdding(false);setEditing(null);}}>Annuler</button>
              <button className="btn bk" onClick={save}>Sauvegarder</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ════ ADMIN CATEGORIES ════
function ACategories({state,dispatch}){
  const[newCat,setNewCat]=useState({label:"",icon:"📦"});
  const[newSubs,setNewSubs]=useState({});
  const[editingCat,setEditingCat]=useState(null);
  const[editForm,setEditForm]=useState({});
  const[saved,setSaved]=useState("");
  const CATS=state.cats;

  const addCat=()=>{
    if(!newCat.label.trim())return;
    dispatch({type:"ADD_CAT",label:newCat.label.trim(),icon:newCat.icon||"📦"});
    setNewCat({label:"",icon:"📦"});
    setSaved("Catégorie ajoutée !");setTimeout(()=>setSaved(""),2000);
  };
  const saveCatEdit=()=>{
    dispatch({type:"UPD_CAT",id:editingCat,data:editForm});
    setEditingCat(null);setSaved("Catégorie modifiée !");setTimeout(()=>setSaved(""),2000);
  };
  const addSub=(catId)=>{
    const sub=(newSubs[catId]||"").trim();
    if(!sub)return;
    dispatch({type:"ADD_SUB",catId,sub});
    setNewSubs({...newSubs,[catId]:""});
    setSaved("Sous-catégorie ajoutée !");setTimeout(()=>setSaved(""),2000);
  };

  return(
    <div>
      <h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700,marginBottom:6}}>Catégories & Sous-catégories</h1>
      <p style={{color:"var(--mid)",fontSize:".85rem",marginBottom:22}}>Gérez l'arborescence du catalogue produits</p>
      {saved&&<div className="ok">✓ {saved}</div>}

      {/* Ajouter catégorie */}
      <div className="card" style={{padding:20,marginBottom:20}}>
        <div style={{fontWeight:700,marginBottom:14}}>➕ Ajouter une nouvelle catégorie</div>
        <div style={{display:"flex",gap:10,alignItems:"flex-end",flexWrap:"wrap"}}>
          <div className="fg" style={{flex:1,marginBottom:0}}><label>Icône (emoji)</label><input value={newCat.icon} onChange={e=>setNewCat({...newCat,icon:e.target.value})} style={{width:80}} placeholder="📦"/></div>
          <div className="fg" style={{flex:4,marginBottom:0}}><label>Nom de la catégorie</label><input value={newCat.label} onChange={e=>setNewCat({...newCat,label:e.target.value})} placeholder="Ex: Matériaux de construction" onKeyDown={e=>e.key==="Enter"&&addCat()}/></div>
          <button className="btn bk" onClick={addCat}>Ajouter</button>
        </div>
      </div>

      {/* Liste des catégories */}
      {CATS.filter(c=>c.id!=="all").map(cat=>(
        <div key={cat.id} className="card" style={{padding:20,marginBottom:14}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
            {editingCat===cat.id?(
              <div style={{display:"flex",gap:10,alignItems:"center",flex:1,flexWrap:"wrap"}}>
                <input value={editForm.icon||""} onChange={e=>setEditForm({...editForm,icon:e.target.value})} style={{width:70}} placeholder="Icône"/>
                <input value={editForm.label||""} onChange={e=>setEditForm({...editForm,label:e.target.value})} style={{flex:1,maxWidth:300}} placeholder="Nom"/>
                <button className="btn gn sm" onClick={saveCatEdit}>✓ Valider</button>
                <button className="btn gh sm" onClick={()=>setEditingCat(null)}>Annuler</button>
              </div>
            ):(
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <span style={{fontSize:"1.4rem"}}>{cat.icon}</span>
                <span style={{fontFamily:"var(--ser)",fontWeight:700,fontSize:"1.05rem"}}>{cat.label}</span>
                <span style={{fontSize:".72rem",color:"var(--mid)",background:"#F4F4F4",padding:"2px 8px",borderRadius:12}}>{cat.subs?.length||0} sous-catégorie(s)</span>
              </div>
            )}
            {editingCat!==cat.id&&(
              <div style={{display:"flex",gap:6}}>
                <button className="btn gh sm" onClick={()=>{setEditingCat(cat.id);setEditForm({icon:cat.icon,label:cat.label});}}>✏ Modifier</button>
                {!["pompe","sanitaire","raccord"].includes(cat.id)&&(
                  <button className="btn rd sm" onClick={()=>{if(confirm(`Supprimer la catégorie "${cat.label}" ?`))dispatch({type:"DEL_CAT",id:cat.id});}}>🗑</button>
                )}
              </div>
            )}
          </div>

          {/* Sous-catégories */}
          <div style={{paddingLeft:16,borderLeft:"2px solid var(--bd)"}}>
            <div style={{fontSize:".72rem",fontWeight:800,letterSpacing:".5px",textTransform:"uppercase",color:"var(--mid)",marginBottom:8}}>Sous-catégories</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:7,marginBottom:12}}>
              {(cat.subs||[]).map(sc=>(
                <div key={sc} style={{display:"inline-flex",alignItems:"center",gap:5,background:"#F4F4F4",borderRadius:20,padding:"4px 10px 4px 12px",fontSize:".8rem",fontWeight:500}}>
                  {sc}
                  <button onClick={()=>{if(confirm(`Supprimer "${sc}" ?`))dispatch({type:"DEL_SUB",catId:cat.id,sub:sc});}} style={{background:"none",border:"none",cursor:"pointer",color:"#9CA3AF",fontSize:".75rem",lineHeight:1,padding:"0 2px"}}>✕</button>
                </div>
              ))}
              {(cat.subs||[]).length===0&&<span style={{fontSize:".8rem",color:"var(--mid)",fontStyle:"italic"}}>Aucune sous-catégorie</span>}
            </div>
            <div style={{display:"flex",gap:8,alignItems:"center"}}>
              <input value={newSubs[cat.id]||""} onChange={e=>setNewSubs({...newSubs,[cat.id]:e.target.value})}
                placeholder="Nouvelle sous-catégorie…" style={{maxWidth:280,fontSize:".82rem",padding:"6px 10px"}}
                onKeyDown={e=>e.key==="Enter"&&addSub(cat.id)}/>
              <button className="btn cy sm" onClick={()=>addSub(cat.id)}>+ Ajouter</button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}


// ════ ADMIN CREDENTIALS ════
function AdminCredentials({state,dispatch}){
  const admin=state.users.find(u=>u.id===1);
  const[form,setForm]=useState({name:admin?.name||"",username:admin?.username||"",password:"",confirm:""});
  const[saved,setSaved]=useState(false);const[err,setErr]=useState("");
  const save=()=>{
    if(!form.username.trim()||!form.name.trim()){setErr("Le nom et l\'identifiant sont obligatoires.");return;}
    if(form.password&&form.password!==form.confirm){setErr("Les mots de passe ne correspondent pas.");return;}
    const updated={...admin,name:form.name.trim(),username:form.username.trim()};
    if(form.password)updated.password=form.password;
    dispatch({type:"UPD_USER",u:updated});
    setErr("");setSaved(true);setForm(f=>({...f,password:"",confirm:""}));
    setTimeout(()=>setSaved(false),2500);
  };
  return(
    <div className="card" style={{padding:20,marginBottom:18,borderLeft:"3px solid var(--cy)"}}>
      <div style={{fontWeight:700,marginBottom:4}}>🔐 Mes identifiants administrateur</div>
      <p style={{fontSize:".8rem",color:"var(--mid)",marginBottom:14}}>Modifiez votre nom, identifiant de connexion et mot de passe.</p>
      {saved&&<div className="ok">✓ Identifiants mis à jour avec succès</div>}
      {err&&<div className="er">{err}</div>}
      <div className="g2">
        <div className="fg"><label>Nom affiché</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Ex: Administrateur CHS"/></div>
        <div className="fg"><label>Identifiant de connexion</label><input value={form.username} onChange={e=>setForm({...form,username:e.target.value})} placeholder="Ex: admin"/></div>
      </div>
      <div className="g2">
        <div className="fg"><label>Nouveau mot de passe <span style={{color:"var(--mid)",fontWeight:400}}>(laisser vide pour ne pas changer)</span></label><input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="Nouveau mot de passe"/></div>
        <div className="fg"><label>Confirmer le mot de passe</label><input type="password" value={form.confirm} onChange={e=>setForm({...form,confirm:e.target.value})} placeholder="Retaper le mot de passe" onKeyDown={e=>e.key==="Enter"&&save()}/></div>
      </div>
      <div style={{textAlign:"right"}}><button className="btn cy" onClick={save}>🔐 Mettre à jour les identifiants</button></div>
    </div>
  );
}

// ════ ADMIN SITE SETTINGS ════
function ASite({state,dispatch}){
  const[cfg,setCfg]=useState({...state.config});const[saved,setSaved]=useState(false);
  const save=()=>{dispatch({type:"SET_CFG",cfg});setSaved(true);setTimeout(()=>setSaved(false),2500);};
  return(
    <div>
      <h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700,marginBottom:22}}>Paramètres du site</h1>
      {saved&&<div className="ok">✓ Paramètres sauvegardés</div>}

      {/* Admin credentials */}
      <AdminCredentials state={state} dispatch={dispatch}/>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginTop:18}}>
        <div className="card" style={{padding:20}}>
          <div style={{fontWeight:700,marginBottom:14}}>🏢 Informations entreprise</div>
          {[["Nom de l'entreprise","company"],["Téléphone","phone"],["WhatsApp (no de confirmation)","whatsapp"],["Email","email"],["Adresse","address"],["Devise","currency"]].map(([l,k])=>(
            <div className="fg" key={k}><label>{l}</label><input value={cfg[k]||""} onChange={e=>setCfg({...cfg,[k]:e.target.value})}/></div>
          ))}
        </div>
        <div>
          <div className="card" style={{padding:20,marginBottom:14}}>
            <div style={{fontWeight:700,marginBottom:14}}>📢 Bannière promotionnelle</div>
            <div className="fg">
              <label style={{display:"flex",alignItems:"center",gap:7,cursor:"pointer",fontWeight:500}}>
                <input type="checkbox" checked={cfg.showBanner||false} onChange={e=>setCfg({...cfg,showBanner:e.target.checked})} style={{width:"auto"}}/>Afficher la bannière
              </label>
            </div>
            <div className="fg"><label>Texte</label><input value={cfg.bannerText||""} onChange={e=>setCfg({...cfg,bannerText:e.target.value})}/></div>
          </div>
          <div className="card" style={{padding:20}}>
            <div style={{fontWeight:700,marginBottom:10}}>📱 WhatsApp CHS</div>
            <div style={{background:"#D1FAE5",borderRadius:8,padding:12,fontSize:".83rem",color:"#065F46"}}>
              <strong>Numéro configuré :</strong> {cfg.whatsapp||CHS_WA}<br/>
              <span style={{fontSize:".75rem",opacity:.8,display:"block",marginTop:4}}>Les confirmations de commande partent depuis ce numéro vers le client.</span>
            </div>
          </div>
        </div>
      </div>
      <div style={{textAlign:"right",marginTop:16}}><button className="btn bk lg" onClick={save}>💾 Sauvegarder</button></div>
    </div>
  );
}

// ════ ADMIN TEXTES DU SITE ════
function ATexts({state,dispatch}){
  const t=state.texts||DEFAULT_TEXTS;
  const[saved,setSaved]=useState(false);
  const[form,setForm]=useState({...t});
  const save=()=>{
    Object.entries(form).forEach(([k,v])=>dispatch({type:"UPD_TEXT",key:k,value:v}));
    setSaved(true);setTimeout(()=>setSaved(false),2500);
  };
  const reset=()=>{if(confirm("Réinitialiser tous les textes aux valeurs par défaut ?")){dispatch({type:"RESET_TEXTS"});setForm({...DEFAULT_TEXTS});}};
  const field=(label,key,multiline=false)=>(
    <div className="fg" key={key}>
      <label>{label}</label>
      {multiline
        ?<textarea rows={2} value={form[key]||""} onChange={e=>setForm({...form,[key]:e.target.value})}/>
        :<input value={form[key]||""} onChange={e=>setForm({...form,[key]:e.target.value})}/>}
    </div>
  );
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6,flexWrap:"wrap",gap:10}}>
        <h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700}}>Éditeur de textes</h1>
        <div style={{display:"flex",gap:8}}>
          <button className="btn gh sm" onClick={reset}>↺ Réinitialiser</button>
          <button className="btn bk" onClick={save}>💾 Sauvegarder tout</button>
        </div>
      </div>
      <p style={{color:"var(--mid)",fontSize:".85rem",marginBottom:22}}>Modifiez tous les textes visibles sur le site public sans toucher au code.</p>
      {saved&&<div className="ok">✓ Textes mis à jour avec succès ! Visitez le site pour voir les changements.</div>}

      {/* Section Hero */}
      <div className="card" style={{padding:20,marginBottom:16}}>
        <div style={{fontWeight:800,fontSize:".72rem",textTransform:"uppercase",letterSpacing:"1px",color:"var(--cy)",marginBottom:14}}>🎯 Section Hero (page d'accueil)</div>
        {field("Sous-titre au dessus du titre (en cyan)","hero_eyebrow")}
        <div className="g3">
          {field("Titre ligne 1","hero_title_line1")}
          {field("Titre ligne 2","hero_title_line2")}
          {field("Titre ligne 3 (accent cyan)","hero_title_accent")}
        </div>
        {field("Sous-titre descriptif","hero_subtitle")}
        {field("Tagline en italique","hero_tagline")}
        <div className="g2">
          {field("Bouton principal","hero_cta_primary")}
          {field("Bouton secondaire","hero_cta_secondary")}
        </div>
      </div>

      {/* Stats Hero */}
      <div className="card" style={{padding:20,marginBottom:16}}>
        <div style={{fontWeight:800,fontSize:".72rem",textTransform:"uppercase",letterSpacing:"1px",color:"var(--cy)",marginBottom:14}}>📊 Statistiques (barre sous le hero)</div>
        <div className="g2">
          {field("Stat 1 — Chiffre","hero_stat1_value")}
          {field("Stat 1 — Label","hero_stat1_label")}
        </div>
        <div className="g2">
          {field("Stat 2 — Chiffre","hero_stat2_value")}
          {field("Stat 2 — Label","hero_stat2_label")}
        </div>
        <div className="g2">
          {field("Stat 3 — Chiffre","hero_stat3_value")}
          {field("Stat 3 — Label","hero_stat3_label")}
        </div>
        <div className="g2">
          {field("Stat 4 — Chiffre","hero_stat4_value")}
          {field("Stat 4 — Label","hero_stat4_label")}
        </div>
      </div>

      {/* Catalogue */}
      <div className="card" style={{padding:20,marginBottom:16}}>
        <div style={{fontWeight:800,fontSize:".72rem",textTransform:"uppercase",letterSpacing:"1px",color:"var(--cy)",marginBottom:14}}>🏪 Section Catalogue (gammes de produits)</div>
        {field("Titre principal","catalog_title")}
        {field("Sous-titre","catalog_subtitle",true)}
        {field("Description catégorie Pompes","cat_pompe_desc",true)}
        {field("Description catégorie Sanitaires","cat_sanitaire_desc",true)}
        {field("Description catégorie Raccords","cat_raccord_desc",true)}
      </div>

      {/* Vedettes */}
      <div className="card" style={{padding:20,marginBottom:16}}>
        <div style={{fontWeight:800,fontSize:".72rem",textTransform:"uppercase",letterSpacing:"1px",color:"var(--cy)",marginBottom:14}}>⭐ Section Produits vedettes</div>
        <div className="g2">
          {field("Titre","featured_title")}
          {field("Sous-titre","featured_subtitle")}
        </div>
      </div>

      {/* Footer */}
      <div className="card" style={{padding:20,marginBottom:20}}>
        <div style={{fontWeight:800,fontSize:".72rem",textTransform:"uppercase",letterSpacing:"1px",color:"var(--cy)",marginBottom:14}}>🦶 Footer</div>
        {field("Description de l'entreprise (sous le logo)","footer_description",true)}
        <div style={{background:"#F5F7FA",borderRadius:8,padding:12,fontSize:".8rem",color:"var(--mid)"}}>
          💡 Pour modifier le téléphone, email, adresse : allez dans <strong>Paramètres du site</strong>.
        </div>
      </div>

      <div style={{textAlign:"right",marginTop:4}}>
        <button className="btn bk lg" onClick={save}>💾 Sauvegarder tous les textes</button>
      </div>
    </div>
  );
}

// ════ ADMIN PUBLISH ════
function APublish(){
  const[step,setStep]=useState(0);
  const steps=[
    {t:"Choisir l'hébergement",c:<div>
      <p style={{marginBottom:14,fontSize:".88rem",lineHeight:1.7}}>Pour mettre votre site en ligne, choisissez un hébergeur. Voici les meilleures options pour le Sénégal :</p>
      <div style={{display:"grid",gap:10}}>
        {[{n:"Vercel",tag:"⭐ Recommandé",url:"vercel.com",d:"Gratuit, déploiement en 1 clic, HTTPS automatique, domaine .vercel.app offert."},
          {n:"Netlify",tag:"Très facile",url:"netlify.com",d:"Glisser-déposer votre dossier → site en ligne en 30 secondes. Gratuit."},
          {n:"Hébergeur local SN",tag:"Local .sn",url:"sonatel.sn",d:"Hébergeurs sénégalais pour un domaine .sn. Contactez Sonatel ou un hébergeur local."},
        ].map(h=>(
          <div key={h.n} className="card" style={{padding:14,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
            <div><div style={{display:"flex",gap:7,alignItems:"center",marginBottom:4}}><span style={{fontWeight:700}}>{h.n}</span><span style={{background:"#F5F5F5",color:"#374151",padding:"1px 7px",borderRadius:12,fontSize:".68rem",fontWeight:700}}>{h.tag}</span></div><div style={{fontSize:".81rem",color:"var(--mid)"}}>{h.d}</div></div>
            <a href={`https://${h.url}`} target="_blank" rel="noopener noreferrer" className="btn gh sm">↗ {h.url}</a>
          </div>
        ))}
      </div>
    </div>},
    {t:"Déployer le site",c:<div>
      <div style={{background:"#080808",color:"#A3E635",borderRadius:8,padding:16,fontFamily:"monospace",fontSize:".8rem",lineHeight:1.9,marginBottom:12}}>
        <span style={{color:"#6B7280"}}># Méthode Netlify (la plus simple — 0 ligne de code)</span><br/>
        1. Allez sur <span style={{color:"#60A5FA"}}>app.netlify.com/drop</span><br/>
        2. Glissez votre dossier de build dans la page<br/>
        3. Votre site est en ligne en 30 secondes !<br/><br/>
        <span style={{color:"#6B7280"}}># Méthode Vercel (avec terminal)</span><br/>
        npm install -g vercel<br/>
        vercel --prod
      </div>
      <div className="ok">✅ Les deux hébergeurs fournissent HTTPS gratuit automatiquement.</div>
    </div>},
    {t:"Configurer votre domaine",c:<div>
      <p style={{marginBottom:13,fontSize:".88rem",lineHeight:1.7}}>Pour un domaine personnalisé (ex: <strong>www.chs-sn.com</strong>), ajoutez ces enregistrements DNS chez votre registrar :</p>
      <div className="card" style={{padding:14,marginBottom:13,overflow:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:".81rem"}}>
          <thead><tr style={{background:"#F5F7FA"}}>{["Type","Nom","Valeur","TTL"].map(h=><th key={h} style={{padding:"7px 11px",textAlign:"left",fontWeight:700}}>{h}</th>)}</tr></thead>
          <tbody>{[["A","@","76.76.21.21","3600"],["CNAME","www","cname.vercel-dns.com","3600"]].map((r,i)=><tr key={i} style={{borderTop:"1px solid var(--bd)"}}>{r.map((c,j)=><td key={j} style={{padding:"7px 11px",fontFamily:j===2?"monospace":"inherit",color:j===2?"var(--cy)":"inherit"}}>{c}</td>)}</tr>)}</tbody>
        </table>
      </div>
      <p style={{fontSize:".82rem",color:"var(--mid)"}}>⏱ La propagation DNS prend 24 à 48h. Votre site sera ensuite accessible en HTTPS.</p>
    </div>},
    {t:"Checklist avant mise en ligne",c:<div>
      <div className="card" style={{padding:18}}>
        {["✓ Vérifier tous les produits Shimge et leurs prix","✓ Vérifier les articles sanitaires et raccords","✓ Tester la commande sur mobile et desktop","✓ Configurer le numéro WhatsApp CHS (+221 77 529 48 14)","✓ Renseigner les coordonnées de l'entreprise","✓ Tester le portail Admin (admin) et Vendeur","✓ Activer la bannière promotionnelle","✓ Créer les comptes vendeurs pour l'équipe","✓ Vérifier la bannière et les textes d'accueil"].map(item=>(
          <div key={item} style={{display:"flex",gap:10,alignItems:"center",padding:"8px 0",borderBottom:"1px solid var(--bd)",fontSize:".86rem"}}>
            <input type="checkbox" style={{width:"auto",flexShrink:0}}/>{item}
          </div>
        ))}
      </div>
    </div>},
  ];
  return(
    <div>
      <h1 style={{fontFamily:"var(--ser)",fontSize:"1.8rem",fontWeight:700,marginBottom:22}}>Publication du site</h1>
      <div style={{display:"flex",gap:7,marginBottom:22}}>
        {steps.map((s,i)=><button key={i} className={`btn sm ${step===i?"bk":"gh"}`} onClick={()=>setStep(i)}>Étape {i+1}</button>)}
      </div>
      <div className="card" style={{padding:26}}>
        <h2 style={{fontFamily:"var(--ser)",fontSize:"1.35rem",fontWeight:700,marginBottom:18}}>{step+1}. {steps[step].t}</h2>
        {steps[step].c}
        <div style={{display:"flex",justifyContent:"space-between",marginTop:18}}>
          <button className="btn gh" onClick={()=>setStep(Math.max(0,step-1))} disabled={step===0}>← Précédent</button>
          <button className="btn bk" onClick={()=>setStep(Math.min(steps.length-1,step+1))} disabled={step===steps.length-1}>Suivant →</button>
        </div>
      </div>
    </div>
  );
}

// ════ FOOTER ════
function Footer({config,texts}){
  const t=texts||DEFAULT_TEXTS;
  return(
    <footer style={{background:"#080808",color:"rgba(255,255,255,.68)",padding:"42px 24px 22px",marginTop:50}}>
      <div style={{maxWidth:1280,margin:"0 auto"}}>
        <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",gap:28,marginBottom:28}}>
          <div>
            <Logo h={30} dark/>
            <div style={{fontSize:".74rem",color:"var(--cy)",marginTop:9,marginBottom:9,letterSpacing:".5px"}}>Compagnie Hydraulique du Sénégal</div>
            <p style={{fontSize:".8rem",lineHeight:1.8,opacity:.6,maxWidth:270}}>{config.tagline}. {t.footer_description}</p>
            <div style={{marginTop:14,fontSize:".8rem",display:"flex",flexDirection:"column",gap:4}}>
              <span>📞 {config.phone}</span><span>✉ {config.email}</span><span>📍 {config.address}</span>
            </div>
          </div>
          {[{t:"Produits",l:["Pompes Shimge","Articles sanitaires","Raccords hydrauliques","Accessoires"]},{t:"Services",l:["Devis gratuit","Livraison","Installation","SAV"]},{t:"CHS",l:["À propos","Contact","Conditions générales","Mentions légales"]}].map(col=>(
            <div key={col.t}>
              <div style={{fontWeight:700,color:"#fff",marginBottom:12,fontSize:".83rem"}}>{col.t}</div>
              {col.l.map(l=><div key={l} style={{fontSize:".78rem",marginBottom:6,opacity:.55,cursor:"pointer"}}>{l}</div>)}
            </div>
          ))}
        </div>
        <div style={{display:"flex",justifyContent:"space-between",borderTop:"1px solid rgba(255,255,255,.08)",paddingTop:18,fontSize:".73rem",opacity:.42,alignItems:"center",flexWrap:"wrap",gap:10}}>
          <span>© {new Date().getFullYear()} CHS — Compagnie Hydraulique du Sénégal. Tous droits réservés.</span>
          <div style={{display:"flex",gap:2}}><div style={{width:20,height:12,background:"#1A5C32",borderRadius:2}}/><div style={{width:20,height:12,background:"rgba(255,255,255,.2)",borderRadius:2}}/><div style={{width:20,height:12,background:"#B91C1C",borderRadius:2}}/></div>
        </div>
      </div>
    </footer>
  );
}

// ════ APP ROOT ════
export default function App(){
  const saved=loadState();
  const[state,dispatch]=useReducer(reducer,saved||INIT);
  const isAdmin=state.page==="admin";

  // Persist to localStorage on every state change
  useEffect(()=>{ saveState(state); },[state]);

  const renderAdmin=()=>{
    if(!state.user)return <LoginPage state={state} dispatch={dispatch}/>;
    return(
      <AdminLayout state={state} dispatch={dispatch}>
        {state.adminSection==="dashboard"&&<ADash state={state} dispatch={dispatch}/>}
        {state.adminSection==="orders"&&<AOrders state={state} dispatch={dispatch}/>}
        {state.adminSection==="products"&&state.user.role==="admin"&&<AProducts state={state} dispatch={dispatch}/>}
        {state.adminSection==="categories"&&state.user.role==="admin"&&<ACategories state={state} dispatch={dispatch}/>}
        {state.adminSection==="texts"&&state.user.role==="admin"&&<ATexts state={state} dispatch={dispatch}/>}
        {state.adminSection==="users"&&state.user.role==="admin"&&<AUsers state={state} dispatch={dispatch}/>}
        {state.adminSection==="site"&&state.user.role==="admin"&&<ASite state={state} dispatch={dispatch}/>}
        {state.adminSection==="publish"&&state.user.role==="admin"&&<APublish/>}
      </AdminLayout>
    );
  };
  return(
    <>
      <style>{CSS}</style>
      {!isAdmin&&<Banner state={state} dispatch={dispatch}/>}
      {!isAdmin&&<Header state={state} dispatch={dispatch}/>}
      {state.page==="home"&&<><Hero dispatch={dispatch} texts={state.texts}/><CatCards dispatch={dispatch} texts={state.texts}/><Featured state={state} dispatch={dispatch}/></>}
      {state.page==="shop"&&<ShopPage state={state} dispatch={dispatch}/>}
      {state.page==="product"&&<ProdDetail state={state} dispatch={dispatch}/>}
      {state.page==="cart"&&<CartPage state={state} dispatch={dispatch}/>}
      {state.page==="login"&&<LoginPage state={state} dispatch={dispatch}/>}
      {state.page==="admin"&&renderAdmin()}
      {!isAdmin&&state.page!=="login"&&<Footer config={state.config} texts={state.texts}/>}
    </>
  );
}
